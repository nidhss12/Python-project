"""Matplotlib charts. Figures are built with the object API so no GUI backend is needed."""
from __future__ import annotations

from pathlib import Path

from . import config as cfg

try:
    import matplotlib
    from matplotlib.figure import Figure
    from matplotlib.ticker import FuncFormatter
    AVAILABLE = True
except ImportError:  # the terminal app keeps working without Matplotlib
    AVAILABLE = False

STYLE = {
    "font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": "#C9D3CF",
    "axes.labelcolor": cfg.INK, "xtick.color": "#4A5F5A", "ytick.color": "#4A5F5A",
    "axes.spines.top": False, "axes.spines.right": False, "text.color": cfg.INK,
}
FACE = "#FFFFFF"


def _money_axis(axis):
    axis.set_major_formatter(FuncFormatter(lambda v, _: f"{cfg.CURRENCY}{v:,.0f}"))


def _new(title: str, subtitle: str = "", size=(8.6, 4.6)):
    fig = Figure(figsize=size, dpi=140, facecolor=FACE)
    ax = fig.add_subplot(111)
    ax.set_facecolor(FACE)
    fig.text(0.04, 0.955, title, fontsize=14, fontweight="bold", color=cfg.INK, va="top")
    if subtitle:
        fig.text(0.04, 0.895, subtitle, fontsize=9, color="#5E726D", va="top")
    return fig, ax


def _empty(fig, ax):
    ax.axis("off")
    ax.text(0.5, 0.5, "No donations yet", ha="center", va="center", fontsize=12, color="#8A9A9E")
    return fig


def monthly_trend(summary: dict):
    with matplotlib.rc_context(STYLE):
        fig, ax = _new("Monthly giving", "Total donated each month")
        months = summary.get("monthly", [])
        if not months:
            return _empty(fig, ax)
        labels = [m["month"] for m in months]
        values = [m["total"] for m in months]
        x = list(range(len(values)))
        ax.fill_between(x, values, color=cfg.ACCENT, alpha=0.22)
        ax.plot(x, values, color=cfg.INK, linewidth=2.2, marker="o", markersize=5, markerfacecolor=FACE,
                markeredgewidth=1.8)
        if len(values) >= 3:  # 3-month moving average
            avg = [sum(values[max(0, i - 2):i + 1]) / len(values[max(0, i - 2):i + 1]) for i in x]
            ax.plot(x, avg, color=cfg.ACCENT, linewidth=1.8, linestyle=(0, (4, 3)), label="3-month average")
            ax.legend(frameon=False, loc="upper left", fontsize=8)
        peak = max(range(len(values)), key=values.__getitem__)
        ax.annotate(f"{cfg.money(values[peak])}", (peak, values[peak]), textcoords="offset points",
                    xytext=(0, 9), ha="center", fontsize=8, color=cfg.INK, fontweight="bold")
        ax.set_xticks(x)
        ax.set_xticklabels([lab[2:] for lab in labels], rotation=45 if len(x) > 8 else 0, fontsize=8)
        ax.set_ylim(0, max(values) * 1.18 or 1)
        _money_axis(ax.yaxis)
        ax.grid(axis="y", color="#E6ECE9", linewidth=0.8)
        ax.set_axisbelow(True)
        fig.subplots_adjust(top=0.80, bottom=0.14, left=0.12, right=0.97)
        return fig


def cause_bar(summary: dict):
    with matplotlib.rc_context(STYLE):
        fig, ax = _new("Giving by cause", "Total raised per cause")
        rows = summary.get("by_cause", [])
        if not rows:
            return _empty(fig, ax)
        rows = rows[::-1]
        bars = ax.barh([r["cause"] for r in rows], [r["total"] for r in rows],
                       color=[cfg.CAUSE_COLORS.get(r["cause"], "#8A9A9E") for r in rows], height=0.62)
        top = max(r["total"] for r in rows)
        for bar, r in zip(bars, rows):
            ax.text(bar.get_width() + top * 0.012, bar.get_y() + bar.get_height() / 2,
                    f"{cfg.money(r['total'])}  ({r['share']:.0f}%)", va="center", fontsize=8.5)
        ax.set_xlim(0, top * 1.38)
        _money_axis(ax.xaxis)
        ax.spines["left"].set_visible(False)
        ax.tick_params(axis="y", length=0)
        ax.grid(axis="x", color="#E6ECE9", linewidth=0.8)
        ax.set_axisbelow(True)
        fig.subplots_adjust(top=0.80, bottom=0.10, left=0.20, right=0.97)
        return fig


def cause_donut(summary: dict):
    with matplotlib.rc_context(STYLE):
        fig, ax = _new("Share of giving", "Percentage of the total by cause", size=(7.2, 4.6))
        rows = summary.get("by_cause", [])
        if not rows:
            return _empty(fig, ax)
        wedges, _ = ax.pie([r["total"] for r in rows],
                           colors=[cfg.CAUSE_COLORS.get(r["cause"], "#8A9A9E") for r in rows],
                           startangle=90, counterclock=False,
                           wedgeprops={"width": 0.38, "edgecolor": FACE, "linewidth": 2})
        ax.text(0, 0.06, cfg.money(summary["total"]), ha="center", fontsize=13, fontweight="bold")
        ax.text(0, -0.14, "total raised", ha="center", fontsize=8.5, color="#5E726D")
        ax.legend(wedges, [f"{r['cause']}  {r['share']:.1f}%" for r in rows], loc="center left",
                  bbox_to_anchor=(1.0, 0.5), frameon=False, fontsize=8.5)
        fig.subplots_adjust(top=0.80, bottom=0.04, left=0.02, right=0.68)
        return fig


def top_donors(summary: dict):
    with matplotlib.rc_context(STYLE):
        fig, ax = _new("Top donors", "Largest contributors by total given", size=(8.6, 4.0))
        rows = summary.get("top_donors", [])
        if not rows:
            return _empty(fig, ax)
        rows = rows[::-1]
        bars = ax.barh([r["donor"] for r in rows], [r["total"] for r in rows], color=cfg.INK, height=0.58)
        top = max(r["total"] for r in rows)
        for bar, r in zip(bars, rows):
            ax.text(bar.get_width() + top * 0.012, bar.get_y() + bar.get_height() / 2,
                    f"{cfg.money(r['total'])}  ({r['count']} gift{'s' if r['count'] != 1 else ''})",
                    va="center", fontsize=8.5)
        ax.set_xlim(0, top * 1.4)
        _money_axis(ax.xaxis)
        ax.spines["left"].set_visible(False)
        ax.tick_params(axis="y", length=0)
        ax.grid(axis="x", color="#E6ECE9", linewidth=0.8)
        ax.set_axisbelow(True)
        fig.subplots_adjust(top=0.78, bottom=0.10, left=0.24, right=0.97)
        return fig


CHARTS = {
    "monthly_trend": monthly_trend,
    "cause_bar": cause_bar,
    "cause_share": cause_donut,
    "top_donors": top_donors,
}


def save_all(summary: dict, folder: Path | str) -> list[Path]:
    """Render every chart to PNG in folder. Returns the written paths."""
    if not AVAILABLE:
        return []
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    paths = []
    for name, builder in CHARTS.items():
        path = folder / f"{name}.png"
        builder(summary).savefig(path, facecolor=FACE)
        paths.append(path)
    return paths


def to_png_bytes(fig) -> bytes:
    import io
    buf = io.BytesIO()
    fig.savefig(buf, format="png", facecolor=FACE)
    return buf.getvalue()
