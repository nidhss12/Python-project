"""Central configuration: paths, limits and domain lists."""
from __future__ import annotations

import os
from pathlib import Path

APP_NAME = "Charity Donation Ledger"
TAGLINE = "Every gift, recorded by cause."

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
EXPORT_DIR = ROOT / "exports"
DATA_FILE = Path(os.environ.get("LEDGER_DATA", DATA_DIR / "donations.json"))
SAMPLE_JSON = DATA_DIR / "sample_donations.json"
SAMPLE_CSV = DATA_DIR / "sample_donations.csv"
BAD_IMPORT_SAMPLE = DATA_DIR / "bad_import_example.csv"

# Change with the LEDGER_CURRENCY environment variable (e.g. "Rs ", "EUR ").
CURRENCY = os.environ.get("LEDGER_CURRENCY", "$")

# Domain constraints
MIN_AMOUNT = 0.01
MAX_AMOUNT = 1_000_000.00
MIN_DATE_YEAR = 2000
MAX_NAME_LEN = 60
MAX_NOTES_LEN = 200

# Thresholds for warning indicators
LARGE_GIFT_LIMIT = 10_000.00      # a gift at or above this is flagged
OUTLIER_Z = 3.0                   # z-score above which a gift is "unusual"
LOW_SHARE_PCT = 3.0               # a cause below this share is flagged
DROP_ALERT_PCT = 30.0             # month-over-month fall that is flagged
QUIET_DAYS = 45                   # days without any gift before flagging
TREND_BAND_PCT = 5.0              # slope (as % of mean) counted as "steady"

CAUSES = [
    "Education",
    "Health",
    "Disaster Relief",
    "Environment",
    "Animal Welfare",
    "Hunger & Food",
    "Other",
]

PAYMENT_METHODS = ["Cash", "Card", "UPI", "Bank Transfer", "Cheque", "Online", "Other"]

# Fixed colour per cause so charts and the GUI always agree.
CAUSE_COLORS = {
    "Education": "#2F6F8F",
    "Health": "#D1495B",
    "Disaster Relief": "#EDAE49",
    "Environment": "#4C9F70",
    "Animal Welfare": "#8E6C8A",
    "Hunger & Food": "#E07A3F",
    "Other": "#8A9A9E",
}
INK = "#16403A"        # deep pine
ACCENT = "#F2A93B"     # saffron
MIST = "#F3F6F4"       # page background


def money(value: float) -> str:
    """Format a number as currency, e.g. $1,234.50."""
    return f"{CURRENCY}{value:,.2f}"
