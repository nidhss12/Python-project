"""Executive summary maths and multi-format report export."""
from __future__ import annotations

import csv
import io
import statistics
from collections import defaultdict
from datetime import date, datetime
from pathlib import Path

from . import config as cfg
from .config import money
from .models import Donation


# ------------------------------------------------------------------ maths
def _month_range(first: str, last: str) -> list[str]:
    y, m = int(first[:4]), int(first[5:7])
    ey, em = int(last[:4]), int(last[5:7])
    out = []
    while (y, m) <= (ey, em):
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return out


def _slope_pct(values: list[float]) -> float:
    """Least-squares slope per month, as a percentage of the mean."""
    n = len(values)
    mean = sum(values) / n if n else 0
    if n < 3 or mean == 0:
        return 0.0
    xs = range(n)
    x_mean = (n - 1) / 2
    num = sum((x - x_mean) * (y - mean) for x, y in zip(xs, values))
    den = sum((x - x_mean) ** 2 for x in xs)
    return (num / den) / mean * 100 if den else 0.0


def build_summary(donations: list[Donation], today: date | None = None) -> dict:
    """Aggregate totals, averages, per-cause shares, top donors, monthly trend and status."""
    today = today or date.today()
    if not donations:
        return {"count": 0, "total": 0.0, "status": "No data", "status_icon": "o",
                "status_note": "Record a donation to see your summary.", "by_cause": [],
                "top_donors": [], "monthly": [], "by_method": [], "today": today.isoformat()}

    amounts = [d.amount for d in donations]
    total = round(sum(amounts), 2)

    by_cause = defaultdict(lambda: [0.0, 0])
    by_method = defaultdict(lambda: [0.0, 0])
    donors = defaultdict(lambda: [0.0, 0, ""])
    months = defaultdict(lambda: [0.0, 0])
    for d in donations:
        by_cause[d.cause][0] += d.amount
        by_cause[d.cause][1] += 1
        by_method[d.payment_method][0] += d.amount
        by_method[d.payment_method][1] += 1
        key = d.donor_name.lower()
        donors[key][0] += d.amount
        donors[key][1] += 1
        donors[key][2] = donors[key][2] or d.donor_name
        months[d.month][0] += d.amount
        months[d.month][1] += 1

    cause_rows = [
        {"cause": c, "total": round(t, 2), "count": n, "average": round(t / n, 2),
         "share": round(t / total * 100, 1)}
        for c, (t, n) in sorted(by_cause.items(), key=lambda kv: kv[1][0], reverse=True)
    ]
    method_rows = [{"method": m, "total": round(t, 2), "count": n}
                   for m, (t, n) in sorted(by_method.items(), key=lambda kv: kv[1][0], reverse=True)]
    top = [{"donor": name, "total": round(t, 2), "count": n}
           for _, (t, n, name) in sorted(donors.items(), key=lambda kv: kv[1][0], reverse=True)[:5]]

    all_months = sorted(months)
    monthly = [{"month": m, "total": round(months[m][0], 2) if m in months else 0.0,
                "count": months[m][1] if m in months else 0}
               for m in _month_range(all_months[0], all_months[-1])]

    # Compare complete months only; the running month would always look like a drop.
    current = today.strftime("%Y-%m")
    complete = [m for m in monthly if m["month"] < current] or monthly
    mom = None
    if len(complete) >= 2 and complete[-2]["total"] > 0:
        mom = round((complete[-1]["total"] - complete[-2]["total"]) / complete[-2]["total"] * 100, 1)
    slope = _slope_pct([m["total"] for m in complete])
    if len(complete) < 3:
        status, icon, note = "Too early to tell", "o", "Add a few more months of gifts to see a trend."
    elif slope > cfg.TREND_BAND_PCT:
        status, icon, note = "Growing", "^", f"Monthly giving is trending up (about {slope:+.1f}% a month)."
    elif slope < -cfg.TREND_BAND_PCT:
        status, icon, note = "Declining", "v", f"Monthly giving is trending down (about {slope:+.1f}% a month)."
    else:
        status, icon, note = "Steady", "=", "Monthly giving is holding steady."
    best = max(monthly, key=lambda m: m["total"])
    dates = sorted(d.date for d in donations)

    return {
        "count": len(donations), "total": total, "average": round(total / len(donations), 2),
        "median": round(statistics.median(amounts), 2),
        "largest": max(donations, key=lambda d: d.amount),
        "smallest": min(donations, key=lambda d: d.amount),
        "unique_donors": len(donors), "first_date": dates[0], "last_date": dates[-1],
        "avg_per_month": round(total / len(monthly), 2),
        "by_cause": cause_rows, "by_method": method_rows, "top_donors": top,
        "monthly": monthly, "best_month": best, "mom_change_pct": mom,
        "slope_pct": round(slope, 1), "status": status, "status_icon": icon,
        "status_note": note, "today": today.isoformat(),
    }


# --------------------------------------------------------------- rendering
def _grid(headers: list[str], rows: list[list[str]], right: set[int] = frozenset()) -> str:
    widths = [max(len(str(x)) for x in col) for col in zip(headers, *rows)]
    def fmt(cells):
        return "  ".join(str(c).rjust(w) if i in right else str(c).ljust(w)
                         for i, (c, w) in enumerate(zip(cells, widths)))
    return "\n".join([fmt(headers), "  ".join("-" * w for w in widths)] + [fmt(r) for r in rows])


def to_text(s: dict) -> str:
    if not s["count"]:
        return "No donations recorded yet.\n"
    out = [
        f"{cfg.APP_NAME} - Executive Summary",
        f"Period: {s['first_date']} to {s['last_date']}   |   Generated {datetime.now():%Y-%m-%d %H:%M}",
        "",
        f"Total raised     : {money(s['total'])}",
        f"Donations        : {s['count']}  from {s['unique_donors']} donors",
        f"Average gift     : {money(s['average'])}   (median {money(s['median'])})",
        f"Largest gift     : {money(s['largest'].amount)} - {s['largest'].donor_name} ({s['largest'].date})",
        f"Smallest gift    : {money(s['smallest'].amount)} - {s['smallest'].donor_name} ({s['smallest'].date})",
        f"Average per month: {money(s['avg_per_month'])}",
        f"Best month       : {s['best_month']['month']} ({money(s['best_month']['total'])})",
        f"Status           : [{s['status_icon']}] {s['status']} - {s['status_note']}",
    ]
    if s["mom_change_pct"] is not None:
        out.append(f"Last full month vs previous: {s['mom_change_pct']:+.1f}%")
    out += ["", "BY CAUSE", _grid(
        ["Cause", "Total", "Gifts", "Average", "Share"],
        [[r["cause"], money(r["total"]), r["count"], money(r["average"]), f"{r['share']:.1f}%"]
         for r in s["by_cause"]], right={1, 2, 3, 4})]
    out += ["", "TOP DONORS", _grid(
        ["Donor", "Total", "Gifts"],
        [[r["donor"], money(r["total"]), r["count"]] for r in s["top_donors"]], right={1, 2})]
    out += ["", "MONTHLY TREND", _grid(
        ["Month", "Total", "Gifts"],
        [[m["month"], money(m["total"]), m["count"]] for m in s["monthly"]], right={1, 2})]
    return "\n".join(out) + "\n"


def _md_table(headers, rows) -> str:
    esc = lambda x: str(x).replace("|", "\\|")
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    lines += ["| " + " | ".join(esc(c) for c in r) + " |" for r in rows]
    return "\n".join(lines)


def to_markdown(s: dict, alerts: list | None = None) -> str:
    if not s["count"]:
        return f"# {cfg.APP_NAME}\n\nNo donations recorded yet.\n"
    md = [
        f"# {cfg.APP_NAME} - Executive Summary", "",
        f"*Period {s['first_date']} to {s['last_date']}. Generated {datetime.now():%Y-%m-%d %H:%M}.*", "",
        "## Key figures", "",
        _md_table(["Metric", "Value"], [
            ["Total raised", money(s["total"])],
            ["Donations / donors", f"{s['count']} / {s['unique_donors']}"],
            ["Average (median) gift", f"{money(s['average'])} ({money(s['median'])})"],
            ["Largest gift", f"{money(s['largest'].amount)} - {s['largest'].donor_name}"],
            ["Smallest gift", f"{money(s['smallest'].amount)} - {s['smallest'].donor_name}"],
            ["Best month", f"{s['best_month']['month']} ({money(s['best_month']['total'])})"],
            ["Status", f"{s['status']} - {s['status_note']}"],
        ]), "", "## By cause", "",
        _md_table(["Cause", "Total", "Gifts", "Average", "Share"],
                  [[r["cause"], money(r["total"]), r["count"], money(r["average"]), f"{r['share']:.1f}%"]
                   for r in s["by_cause"]]), "", "## Top donors", "",
        _md_table(["Donor", "Total", "Gifts"],
                  [[r["donor"], money(r["total"]), r["count"]] for r in s["top_donors"]]), "",
        "## Monthly trend", "",
        _md_table(["Month", "Total", "Gifts"],
                  [[m["month"], money(m["total"]), m["count"]] for m in s["monthly"]]), "",
    ]
    if alerts:
        md += ["## Warnings", ""] + [f"- **{a.level.upper()}** {a.title}: {a.detail}" for a in alerts] + [""]
    return "\n".join(md)


def audit_log(donations: list[Donation], summary: dict, alerts: list | None = None) -> str:
    """Plain-text log of every record, suitable for external review."""
    lines = [
        f"{cfg.APP_NAME.upper()} - AUDIT LOG",
        f"Generated : {datetime.now():%Y-%m-%d %H:%M:%S}",
        f"Records   : {len(donations)}",
        f"Total     : {money(summary.get('total', 0))}",
        "=" * 100,
        f"{'ID':>4}  {'DATE':<10}  {'DONOR':<24}  {'CAUSE':<16}  {'AMOUNT':>13}  {'METHOD':<13}  NOTES",
        "-" * 100,
    ]
    for d in sorted(donations, key=lambda x: (x.date, x.id)):
        lines.append(f"{d.id:>4}  {d.date:<10}  {d.donor_name[:24]:<24}  {d.cause:<16}  "
                     f"{money(d.amount):>13}  {d.payment_method:<13}  {d.notes}")
    lines += ["-" * 100, f"{'':>4}  {'':<10}  {'':<24}  {'TOTAL':<16}  {money(summary.get('total', 0)):>13}"]
    if alerts:
        lines += ["", "FLAGS RAISED AT TIME OF EXPORT"]
        lines += [f"  [{a.level.upper()}] {a.title}: {a.detail}" for a in alerts]
    return "\n".join(lines) + "\n"


def _csv_safe(value) -> str:
    """Stop spreadsheet apps from running text that starts with = + - @ as a formula."""
    text = str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@") else text


def summary_csv(s: dict) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["section", "name", "total", "count", "average", "share_pct"])
    for r in s.get("by_cause", []):
        w.writerow(["cause", _csv_safe(r["cause"]), r["total"], r["count"], r["average"], r["share"]])
    for r in s.get("top_donors", []):
        w.writerow(["top_donor", _csv_safe(r["donor"]), r["total"], r["count"],
                    round(r["total"] / r["count"], 2), ""])
    for r in s.get("by_method", []):
        w.writerow(["payment_method", _csv_safe(r["method"]), r["total"], r["count"],
                    round(r["total"] / r["count"], 2), ""])
    for m in s.get("monthly", []):
        w.writerow(["month", m["month"], m["total"], m["count"],
                    round(m["total"] / m["count"], 2) if m["count"] else 0, ""])
    return buf.getvalue()


def donations_csv(donations: list[Donation]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "date", "donor_name", "cause", "amount", "payment_method", "notes"])
    for d in sorted(donations, key=lambda x: (x.date, x.id)):
        w.writerow([d.id, d.date, _csv_safe(d.donor_name), d.cause, f"{d.amount:.2f}",
                    d.payment_method, _csv_safe(d.notes)])
    return buf.getvalue()


def export_all(donations: list[Donation], summary: dict, alerts: list | None = None,
               out_dir: Path | str | None = None, with_charts: bool = True) -> list[Path]:
    """Write Markdown, plain-text audit log, CSV files and (if possible) PNG charts."""
    folder = Path(out_dir) if out_dir else cfg.EXPORT_DIR / datetime.now().strftime("report_%Y%m%d_%H%M%S")
    folder.mkdir(parents=True, exist_ok=True)
    files = {
        "summary_report.md": to_markdown(summary, alerts),
        "summary_report.txt": to_text(summary),
        "audit_log.txt": audit_log(donations, summary, alerts),
        "summary_by_group.csv": summary_csv(summary),
        "donations.csv": donations_csv(donations),
    }
    written = []
    for name, content in files.items():
        path = folder / name
        path.write_text(content, encoding="utf-8", newline="")
        written.append(path)
    if with_charts:
        from . import charts
        if charts.AVAILABLE:
            written += charts.save_all(summary, folder)
    return written
