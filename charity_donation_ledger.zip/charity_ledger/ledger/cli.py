"""Menu-driven terminal interface."""
from __future__ import annotations

import os
import sys
from datetime import date, datetime
from pathlib import Path

from . import __version__
from . import alerts as alerts_mod
from . import config as cfg
from . import importer, reports
from . import validation as v
from .config import money
from .engine import Ledger, NotFound
from .models import Donation
from .storage import Storage, StorageError

# ------------------------------------------------------------------ styling
USE_COLOR = sys.stdout.isatty() and "NO_COLOR" not in os.environ
if os.name == "nt" and USE_COLOR:
    os.system("")  # switches on ANSI escape handling in the Windows console

UNICODE = "utf" in (getattr(sys.stdout, "encoding", "") or "").lower()
H, V_, TL, TR, BL, BR = ("─", "│", "╭", "╮", "╰", "╯") if UNICODE else ("-", "|", "+", "+", "+", "+")
BLOCK = "█" if UNICODE else "#"
CODES = {"bold": "1", "dim": "2", "red": "38;5;167", "green": "38;5;72", "yellow": "38;5;214",
         "pine": "38;5;30", "saffron": "38;5;214", "grey": "38;5;245", "blue": "38;5;67"}


def paint(text: str, *styles: str) -> str:
    if not USE_COLOR:
        return text
    return f"\033[{';'.join(CODES[s] for s in styles)}m{text}\033[0m"


def say(text: str = "") -> None:
    print(text)


def ok(text: str) -> None:
    print(paint("  ✓ " if UNICODE else "  OK ", "green", "bold") + text)


def fail(text: str) -> None:
    print(paint("  ! ", "red", "bold") + text)


def note(text: str) -> None:
    print(paint("  " + text, "grey"))


def rule(title: str = "") -> None:
    if title:
        print("\n" + paint(f"{H}{H} {title} ", "pine", "bold") + paint(H * max(4, 66 - len(title)), "pine"))
    else:
        print(paint(H * 72, "grey"))


def clip(text: str, width: int) -> str:
    text = str(text)
    return text if len(text) <= width else text[: width - 1] + ("…" if UNICODE else ".")


def banner() -> None:
    inner = 54
    lines = [cfg.APP_NAME.upper().center(inner), cfg.TAGLINE.center(inner),
             f"v{__version__}  |  records saved locally".center(inner)]
    print()
    print(paint(TL + H * inner + TR, "pine"))
    print(paint(V_, "pine") + paint(lines[0], "saffron", "bold") + paint(V_, "pine"))
    print(paint(V_, "pine") + paint(lines[1], "grey") + paint(V_, "pine"))
    print(paint(V_, "pine") + paint(lines[2], "grey") + paint(V_, "pine"))
    print(paint(BL + H * inner + BR, "pine"))


# ------------------------------------------------------------------ tables
COLS = [("ID", 4, ">"), ("Date", 10, "<"), ("Donor", 22, "<"), ("Cause", 15, "<"),
        ("Amount", 13, ">"), ("Method", 13, "<")]


COL_SEP = " │ " if UNICODE else " | "
ROW_SEP = H + "┼" + H if UNICODE else "-+-"


def _line(cells) -> str:
    return COL_SEP.join(f"{clip(c, w):{a}{w}}" for c, (_, w, a) in zip(cells, COLS))


def donation_table(rows: list[Donation]) -> str:
    head = _line([c[0] for c in COLS])
    sep = ROW_SEP.join(H * w for _, w, _ in COLS)
    body = [_line([d.id, d.date, d.donor_name, d.cause, money(d.amount), d.payment_method]) for d in rows]
    return "\n".join([paint(head, "bold"), paint(sep, "grey")] + body)


def paginate(rows: list[Donation], title: str, page_size: int = 10) -> None:
    """Show rows page by page. Enter/n = next, p = previous, an ID = details, q = back."""
    if not rows:
        note("Nothing to show.")
        return
    pages = (len(rows) + page_size - 1) // page_size
    page = 0
    while True:
        rule(f"{title}  (page {page + 1} of {pages}, {len(rows)} records)")
        say(donation_table(rows[page * page_size:(page + 1) * page_size]))
        say()
        note(f"Total of these {len(rows)} records: {money(sum(d.amount for d in rows))}")
        if pages == 1:
            hint = "Type an ID for details, or press Enter to go back"
        else:
            hint = "[n]ext  [p]revious  [ID] details  [q] back"
        try:
            cmd = input(paint(f"  {hint}: ", "grey")).strip().lower()
        except (EOFError, KeyboardInterrupt):
            say()
            return
        if cmd in ("q", "quit", "back") or (not cmd and (pages == 1 or page == pages - 1)):
            return
        if cmd in ("", "n", "next"):
            page = min(page + 1, pages - 1)
        elif cmd in ("p", "prev", "previous"):
            page = max(page - 1, 0)
        elif cmd.isdigit():
            match = next((d for d in rows if d.id == int(cmd)), None)
            show_detail(match) if match else fail(f"No record with ID {cmd} in this list.")
        else:
            fail("Type n, p, q or an ID number.")


def show_detail(d: Donation) -> None:
    rule(f"Donation #{d.id}")
    for label, value in [("Date", d.date), ("Donor", d.donor_name), ("Cause", d.cause),
                         ("Amount", money(d.amount)), ("Method", d.payment_method),
                         ("Notes", d.notes or "-")]:
        say(f"  {paint(f'{label:<8}', 'grey')}{value}")


# ------------------------------------------------------------------ prompts
def ask(label, validator, default=None, optional=False, hint=None):
    return v.prompt_until_valid(
        label, validator, default=default, optional=optional, hint=hint,
        error_fmt=lambda m: paint("  ! ", "red", "bold") + m)


def choose_from(title: str, options: list[str]) -> None:
    say(paint(f"  {title}", "bold"))
    for i, opt in enumerate(options, 1):
        say(f"    {paint(str(i), 'saffron')}  {opt}")


def confirm(question: str, default: bool = False) -> bool:
    hint = "Y/n" if default else "y/N"
    answer = ask(question, v.validate_yes_no, default="y" if default else "n", hint=f"[{hint}]")
    return answer


# ------------------------------------------------------------------ actions
def record_donation(ledger: Ledger) -> None:
    rule("Record a donation")
    note("Type /cancel at any prompt to return to the menu.")
    when = ask("Date (YYYY-MM-DD or 'today')", v.validate_date, default=date.today().isoformat())
    donor = ask("Donor name", v.validate_name)
    choose_from("Cause", cfg.CAUSES)
    cause = ask("Cause (number or name)", v.validate_cause)
    amount = ask(f"Amount ({cfg.CURRENCY.strip()})", v.validate_amount)
    choose_from("Payment method", cfg.PAYMENT_METHODS)
    method = ask("Payment method (number or name)", v.validate_payment, default="Cash")
    notes = ask("Notes", v.validate_notes, optional=True) or ""

    say()
    say(f"  {when}  {donor}  ->  {cause}  {paint(money(amount), 'bold')}  via {method}")
    if amount >= cfg.LARGE_GIFT_LIMIT:
        fail(f"This is a large gift (limit {money(cfg.LARGE_GIFT_LIMIT)}). Please double-check the amount.")
    if not confirm("Save this donation?", default=True):
        note("Not saved.")
        return
    saved = ledger.add(when, donor, cause, amount, method, notes)
    ok(f"Saved as donation #{saved.id}. Total for {saved.cause}: "
       f"{money(ledger.totals_by_cause().get(saved.cause, 0))}")


def list_all(ledger: Ledger) -> None:
    paginate(ledger.search(), "All donations")


def search_records(ledger: Ledger) -> None:
    rule("Search & filter")
    note("Press Enter to skip any filter. All filters you fill in are combined.")
    keyword = ask("Keyword (donor, notes, cause...)", lambda r: r, optional=True) or ""
    cause = ask("Cause (name or number, blank = all)", v.validate_cause, optional=True)
    method = ask("Payment method (blank = all)", v.validate_payment, optional=True)
    start = ask("From date (YYYY-MM-DD)", lambda r: v.validate_date(r, allow_future=True), optional=True)
    end = ask("To date (YYYY-MM-DD)", lambda r: v.validate_date(r, allow_future=True), optional=True)
    low = ask("Minimum amount", v.validate_amount, optional=True)
    high = ask("Maximum amount", v.validate_amount, optional=True)
    try:
        rows = ledger.search(keyword, cause, method, start, end, low, high)
    except v.ValidationError as exc:
        fail(str(exc))
        return
    paginate(rows, "Search results")


def _pick_record(ledger: Ledger) -> Donation | None:
    raw = ask("Donation ID (blank to list all first)", v.validate_id, optional=True)
    if raw is None:
        paginate(ledger.search(), "All donations")
        raw = ask("Donation ID", v.validate_id)
    try:
        return ledger.get(raw)
    except NotFound as exc:
        fail(str(exc))
        return None


def edit_record(ledger: Ledger) -> None:
    rule("Edit a donation")
    d = _pick_record(ledger)
    if not d:
        return
    show_detail(d)
    note("Press Enter to keep the current value.")
    changes = {
        "date": ask("Date", lambda r: v.validate_date(r), default=d.date),
        "donor_name": ask("Donor name", v.validate_name, default=d.donor_name),
        "cause": ask("Cause", v.validate_cause, default=d.cause),
        "amount": ask("Amount", v.validate_amount, default=f"{d.amount:.2f}"),
        "payment_method": ask("Payment method", v.validate_payment, default=d.payment_method),
    }
    notes = ask("Notes (type '-' to clear)", v.validate_notes, default=d.notes or None, optional=True)
    changes["notes"] = "" if notes == "-" else (notes or "")
    ledger.edit(d.id, **changes)
    ok(f"Donation #{d.id} updated.")


def delete_record(ledger: Ledger) -> None:
    rule("Delete a donation")
    d = _pick_record(ledger)
    if not d:
        return
    show_detail(d)
    if confirm("Delete this donation permanently?"):
        ledger.delete(d.id)
        ok(f"Donation #{d.id} deleted.")
    else:
        note("Nothing was deleted.")


def _bar(share: float, width: int = 24) -> str:
    return BLOCK * max(1, round(share / 100 * width)) if share > 0 else ""


def show_summary(ledger: Ledger) -> None:
    s = reports.build_summary(ledger.donations)
    rule("Executive summary")
    if not s["count"]:
        note("No donations yet. Record one from the main menu, or load the demo data.")
        return
    colour = {"Growing": "green", "Declining": "red"}.get(s["status"], "yellow")
    say(f"  Total raised     {paint(money(s['total']), 'saffron', 'bold')}")
    say(f"  Donations        {s['count']} from {s['unique_donors']} donors "
        f"({s['first_date']} to {s['last_date']})")
    say(f"  Average / median {money(s['average'])} / {money(s['median'])}")
    say(f"  Largest gift     {money(s['largest'].amount)}  {s['largest'].donor_name}")
    say(f"  Smallest gift    {money(s['smallest'].amount)}  {s['smallest'].donor_name}")
    say(f"  Best month       {s['best_month']['month']}  {money(s['best_month']['total'])}")
    badge = "[" + s["status_icon"] + "] " + s["status"]
    say(f"  Status           {paint(badge, colour, 'bold')}  {s['status_note']}")
    if s["mom_change_pct"] is not None:
        c = "green" if s["mom_change_pct"] >= 0 else "red"
        change = format(s["mom_change_pct"], "+.1f") + "%"
        say(f"  Last full month  {paint(change, c)} vs the month before")

    rule("By cause")
    say(paint(f"  {'Cause':<16}{'Total':>14}{'Gifts':>7}{'Average':>13}{'Share':>8}  ", "bold"))
    for r in s["by_cause"]:
        say(f"  {r['cause']:<16}{money(r['total']):>14}{r['count']:>7}{money(r['average']):>13}"
            f"{r['share']:>7.1f}%  {paint(_bar(r['share']), 'pine')}")

    rule("Top donors")
    for i, r in enumerate(s["top_donors"], 1):
        say(f"  {i}. {clip(r['donor'], 24):<24}{money(r['total']):>14}   {r['count']} gift(s)")

    rule("Monthly trend")
    top = max(m["total"] for m in s["monthly"]) or 1
    for m in s["monthly"]:
        say(f"  {m['month']}  {money(m['total']):>13}  {paint(BLOCK * round(m['total'] / top * 30), 'saffron')}")
    say()
    show_alerts(ledger, heading=False)


def show_alerts(ledger: Ledger, heading: bool = True) -> None:
    found = alerts_mod.find_alerts(ledger.donations)
    if heading:
        rule("Warnings & flags")
    if not found:
        ok("No warnings. Everything looks normal.")
        return
    style = {"critical": ("red", "CRITICAL"), "warning": ("yellow", "WARNING "), "info": ("blue", "NOTICE  ")}
    if not heading:
        rule("Warnings & flags")
    for a in found:
        colour, label = style[a.level]
        say(f"  {paint(label, colour, 'bold')} {paint(a.title, 'bold')}")
        say(f"           {a.detail}")


def make_charts(ledger: Ledger) -> None:
    from . import charts
    rule("Charts")
    if not charts.AVAILABLE:
        fail("Matplotlib is not installed. Run:  pip install matplotlib")
        return
    if not ledger.donations:
        note("No donations yet, so there is nothing to plot.")
        return
    folder = cfg.EXPORT_DIR / "charts"
    paths = charts.save_all(reports.build_summary(ledger.donations), folder)
    ok(f"Saved {len(paths)} charts to {folder}")
    for p in paths:
        note(f"- {p.name}")


def export_reports(ledger: Ledger) -> None:
    rule("Export reports")
    if not ledger.donations:
        note("No donations yet, so there is nothing to export.")
        return
    summary = reports.build_summary(ledger.donations)
    written = reports.export_all(ledger.donations, summary, alerts_mod.find_alerts(ledger.donations))
    ok(f"Wrote {len(written)} files to {written[0].parent}")
    for p in written:
        note(f"- {p.name}")
    from . import charts
    if not charts.AVAILABLE:
        note("(Charts skipped: install Matplotlib to include them.)")


def import_donations(ledger: Ledger) -> None:
    rule("Import donations from CSV")
    note("Required columns: date, donor_name, cause, amount. Optional: payment_method, notes.")
    note(f"Try the messy demo file: {cfg.BAD_IMPORT_SAMPLE}")
    raw = ask("Path to CSV file", lambda r: r if r.strip() else (_ for _ in ()).throw(
        v.ValidationError("Enter a file path.")))
    log = cfg.EXPORT_DIR / f"import_log_{datetime.now():%Y%m%d_%H%M%S}.txt"
    result = importer.import_csv(raw, ledger, log)
    if result.fatal:
        fail(result.fatal)
    else:
        ok(f"Imported {result.imported} of {result.total_rows} rows. "
           f"Skipped {result.skipped}. Warnings: {len(result.warnings)}.")
    for issue in result.errors[:8]:
        say(f"    line {issue.line}: {paint(issue.field, 'red')} - {issue.message}")
    if len(result.errors) > 8:
        note(f"... and {len(result.errors) - 8} more errors")
    if result.log_path:
        note(f"Full row-by-row log: {result.log_path}")


def load_demo(ledger: Ledger, ask_first: bool = True) -> None:
    rule("Load demo data")
    if not cfg.SAMPLE_CSV.exists():
        fail(f"Sample file not found: {cfg.SAMPLE_CSV}")
        return
    if ledger.donations:
        say(f"  You already have {len(ledger.donations)} donations.")
        choice = ask("[a]dd demo rows to them, [r]eplace them (a backup is kept), or [c]ancel",
                     lambda r: r.lower()[:1] if r.lower()[:1] in "arc" and r else (_ for _ in ()).throw(
                         v.ValidationError("Type a, r or c.")), default="c")
        if choice == "c":
            return
        if choice == "r":
            ledger.clear()
    result = importer.import_csv(cfg.SAMPLE_CSV, ledger)
    ok(f"Loaded {result.imported} demo donations.") if result.ok else fail(result.fatal or "Import failed.")


# --------------------------------------------------------------------- menu
MENU = [
    ("1", "Record a donation", record_donation),
    ("2", "View all donations", list_all),
    ("3", "Search & filter", search_records),
    ("4", "Edit a donation", edit_record),
    ("5", "Delete a donation", delete_record),
    ("6", "Executive summary", show_summary),
    ("7", "Warnings & flags", show_alerts),
    ("8", "Create charts (PNG)", make_charts),
    ("9", "Export reports (MD / TXT / CSV)", export_reports),
    ("10", "Import donations from CSV", import_donations),
    ("11", "Load demo data", load_demo),
    ("0", "Exit", None),
]


def print_menu(ledger: Ledger) -> None:
    total = sum(d.amount for d in ledger.donations)
    rule("Main menu")
    for key, label, _ in MENU:
        say(f"  {paint(f'{key:>2}', 'saffron', 'bold')}  {label}")
    say()
    note(f"{len(ledger.donations)} donations on file, {money(total)} raised")


def main(argv: list[str] | None = None) -> int:
    import argparse
    global USE_COLOR
    parser = argparse.ArgumentParser(description=cfg.APP_NAME)
    parser.add_argument("--data", help="path to the JSON data file (default: data/donations.json)")
    parser.add_argument("--no-color", action="store_true", help="turn off ANSI colours")
    args = parser.parse_args(argv)
    if args.no_color:
        USE_COLOR = False

    first_run = not (Path(args.data) if args.data else cfg.DATA_FILE).exists()
    try:
        ledger = Ledger(Storage(args.data) if args.data else None)
    except StorageError as exc:
        fail(str(exc))
        return 1

    banner()
    for message in ledger.load_notes:
        if not first_run:
            fail(message)
    if first_run and not ledger.donations:
        say()
        try:
            if confirm("First launch: load 40 demo donations to explore?", default=True):
                load_demo(ledger)
        except v.InputCancelled:
            pass

    actions = {key: fn for key, _, fn in MENU}
    while True:
        print_menu(ledger)
        try:
            choice = input(paint("\n  Choose an option: ", "bold")).strip()
        except (EOFError, KeyboardInterrupt):
            choice = "0"
        if choice == "0":
            say(paint("\n  Thank you for recording your gifts. Goodbye.\n", "pine"))
            return 0
        action = actions.get(choice)
        if not action:
            fail("Please choose a number from the menu.")
            continue
        try:
            action(ledger)
        except v.InputCancelled:
            note("Cancelled. Back at the menu.")
        except (v.ValidationError, NotFound) as exc:
            fail(str(exc))
        except StorageError as exc:
            fail(f"Could not save: {exc}")
        except Exception as exc:  # last line of defence: never show a traceback in the demo
            fail(f"Something unexpected happened ({type(exc).__name__}: {exc}). Your data is safe.")
