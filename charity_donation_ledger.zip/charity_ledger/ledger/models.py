"""Core data structures."""
from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass
class Donation:
    id: int
    date: str            # ISO date, YYYY-MM-DD
    donor_name: str
    cause: str
    amount: float
    payment_method: str = "Other"
    notes: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def month(self) -> str:
        return self.date[:7]

    @classmethod
    def from_dict(cls, data: dict) -> "Donation":
        """Strict schema check. Raises ValueError/KeyError/TypeError on bad data."""
        from . import validation as v

        if not isinstance(data, dict):
            raise TypeError("record is not an object")
        return cls(
            id=v.validate_id(data["id"]),
            date=v.validate_date(data["date"], allow_future=True),
            donor_name=v.validate_name(data["donor_name"]),
            cause=v.validate_cause(data["cause"]),
            amount=v.validate_amount(data["amount"]),
            payment_method=v.validate_payment(data.get("payment_method") or "Other"),
            notes=v.validate_notes(data.get("notes") or ""),
        )
