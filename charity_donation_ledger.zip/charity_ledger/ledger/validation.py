"""Defensive input validation.

Every validator takes a raw value (usually a string typed by the user),
returns a clean, typed value, or raises ValidationError with a message that
tells the user what to fix. The same validators are used by the terminal
app, the Streamlit GUI, the CSV importer and the storage layer.
"""
from __future__ import annotations

import re
from datetime import date, datetime
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Any, Callable

from . import config as cfg


class ValidationError(ValueError):
    """Raised when a value does not meet the domain constraints."""


class InputCancelled(Exception):
    """Raised when the user types /cancel or presses Ctrl+C at a prompt."""


_CONTROL = re.compile(r"[\x00-\x1f\x7f]")
_SPACES = re.compile(r"\s+")
_NAME_OK = re.compile(r"^[^\W_\d][\w .,'’&()\-]*$", re.UNICODE)
_CURRENCY_CHARS = "$€£₹¥"


def _clean_text(raw: Any) -> str:
    """Strip control characters and collapse runs of whitespace."""
    if raw is None:
        return ""
    return _SPACES.sub(" ", _CONTROL.sub(" ", str(raw))).strip()


# ----------------------------------------------------------------- scalars
def validate_amount(raw: Any) -> float:
    if isinstance(raw, bool):
        raise ValidationError("Amount must be a number, for example 250 or 99.50.")
    text = _clean_text(raw)
    if not text:
        raise ValidationError("Amount is required.")
    text = text.replace(",", "").replace(cfg.CURRENCY.strip(), "")
    for ch in _CURRENCY_CHARS:
        text = text.replace(ch, "")
    try:
        value = Decimal(text.strip())
    except InvalidOperation:
        raise ValidationError(
            f"'{_clean_text(raw)}' is not a number. Use digits only, for example 250 or 99.50."
        ) from None
    if not value.is_finite():
        raise ValidationError("Amount must be a finite number.")
    if value > Decimal(str(cfg.MAX_AMOUNT)):  # check first: quantize() overflows on huge exponents
        raise ValidationError(
            f"Amount is above the {cfg.money(cfg.MAX_AMOUNT)} limit. Check for a typo or split the gift."
        )
    if value <= 0:
        raise ValidationError("Amount must be greater than zero.")
    if value < Decimal("0.005"):
        raise ValidationError(f"Amount must be at least {cfg.money(cfg.MIN_AMOUNT)}.")
    return float(value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def validate_date(raw: Any, allow_future: bool = False, today: date | None = None) -> str:
    today = today or date.today()
    if isinstance(raw, datetime):
        parsed = raw.date()
    elif isinstance(raw, date):
        parsed = raw
    else:
        text = _clean_text(raw)
        if not text:
            raise ValidationError("Date is required. Use the format YYYY-MM-DD.")
        if text.lower() == "today":
            parsed = today
        else:
            try:
                parsed = datetime.strptime(text, "%Y-%m-%d").date()
            except ValueError:
                raise ValidationError(
                    f"'{text}' is not a valid date. Use YYYY-MM-DD, for example 2026-03-15."
                ) from None
    if parsed.year < cfg.MIN_DATE_YEAR:
        raise ValidationError(f"Date must be {cfg.MIN_DATE_YEAR} or later.")
    if not allow_future and parsed > today:
        raise ValidationError(f"{parsed.isoformat()} is in the future. Enter today's date or earlier.")
    return parsed.isoformat()


def validate_name(raw: Any) -> str:
    text = _clean_text(raw)
    if not text:
        raise ValidationError("Donor name is required. Type 'Anonymous' if the donor is unknown.")
    if len(text) < 2:
        raise ValidationError("Donor name needs at least 2 characters.")
    if len(text) > cfg.MAX_NAME_LEN:
        raise ValidationError(f"Donor name is too long (max {cfg.MAX_NAME_LEN} characters).")
    if not _NAME_OK.match(text):
        raise ValidationError(
            "Donor name must start with a letter and use only letters, numbers, spaces and . , ' & ( ) -"
        )
    return text


def _pick(raw: Any, options: list[str], label: str) -> str:
    text = _clean_text(raw)
    if not text:
        raise ValidationError(f"{label} is required.")
    if text.isdigit():
        index = int(text)
        if 1 <= index <= len(options):
            return options[index - 1]
        raise ValidationError(f"Choose a number from 1 to {len(options)}.")
    lowered = text.lower()
    for option in options:
        if option.lower() == lowered:
            return option
    matches = [o for o in options if o.lower().startswith(lowered)]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        raise ValidationError(f"'{text}' matches several options ({', '.join(matches)}). Type more letters.")
    raise ValidationError(f"'{text}' is not a valid {label.lower()}. Options: {', '.join(options)}.")


def validate_cause(raw: Any) -> str:
    return _pick(raw, cfg.CAUSES, "Cause")


def validate_payment(raw: Any) -> str:
    return _pick(raw, cfg.PAYMENT_METHODS, "Payment method")


def validate_notes(raw: Any) -> str:
    text = _clean_text(raw)
    if len(text) > cfg.MAX_NOTES_LEN:
        raise ValidationError(f"Notes are too long ({len(text)}/{cfg.MAX_NOTES_LEN} characters).")
    return text


def validate_id(raw: Any) -> int:
    if isinstance(raw, bool):
        raise ValidationError("ID must be a whole number.")
    try:
        value = int(str(raw).strip())
    except (TypeError, ValueError):
        raise ValidationError("ID must be a whole number, for example 12.") from None
    if value < 1:
        raise ValidationError("ID must be 1 or higher.")
    return value


def validate_yes_no(raw: Any) -> bool:
    text = _clean_text(raw).lower()
    if text in {"y", "yes"}:
        return True
    if text in {"n", "no"}:
        return False
    raise ValidationError("Please answer y or n.")


# ------------------------------------------------------------- prompt loop
def prompt_until_valid(
    label: str,
    validator: Callable[[str], Any],
    default: str | None = None,
    optional: bool = False,
    input_fn: Callable[[str], str] = input,
    print_fn: Callable[[str], None] = print,
    error_fmt: Callable[[str], str] = lambda m: f"  ! {m}",
    hint: str | None = None,
) -> Any:
    """Ask until the validator accepts the answer.

    * Enter with a default accepts the default.
    * Enter on an optional prompt returns None.
    * '/cancel' or Ctrl+C raises InputCancelled so the caller can go back to the menu.
    * Ctrl+D (EOF) is also treated as a cancel so the program never crashes.
    """
    if hint is not None:
        suffix = f" {hint}"
    else:
        suffix = f" [{default}]" if default not in (None, "") else (" (optional)" if optional else "")
    while True:
        try:
            raw = input_fn(f"{label}{suffix}: ")
        except (KeyboardInterrupt, EOFError):
            print_fn("")
            raise InputCancelled() from None
        raw = raw.strip()
        if raw.lower() == "/cancel":
            raise InputCancelled()
        if not raw:
            if default not in (None, ""):
                raw = str(default)
            elif optional:
                return None
        try:
            return validator(raw)
        except ValidationError as exc:
            print_fn(error_fmt(str(exc)))
