"""JSON persistence with schema checks, atomic writes and corruption recovery."""
from __future__ import annotations

import json
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path

from . import config as cfg
from .models import Donation

SCHEMA_VERSION = 1


class StorageError(Exception):
    """Raised when the data file cannot be written."""


class Storage:
    def __init__(self, path: Path | str | None = None):
        self.path = Path(path) if path else cfg.DATA_FILE
        self.notes: list[str] = []   # human-readable messages from the last load

    # ------------------------------------------------------------- loading
    def load(self) -> list[Donation]:
        """Load donations. Never raises for a missing, empty or corrupted file."""
        self.notes = []
        try:
            raw = self.path.read_text(encoding="utf-8")
        except FileNotFoundError:
            self.notes.append("No data file found, so a fresh ledger was created.")
            self._write_template()
            return []
        except UnicodeDecodeError:
            return self._recover("the file is not valid UTF-8 text")
        except OSError as exc:
            raise StorageError(f"Cannot read {self.path}: {exc}") from exc

        if not raw.strip():
            return self._recover("the file is empty")
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            return self._recover(f"it is not valid JSON ({exc.msg} at line {exc.lineno})")

        if isinstance(payload, dict):
            records = payload.get("donations")
        else:
            records = payload  # accept a bare list for hand-edited files
        if not isinstance(records, list):
            return self._recover("it has no 'donations' list")

        donations: list[Donation] = []
        seen: set[int] = set()
        skipped = 0
        for index, item in enumerate(records, start=1):
            try:
                donation = Donation.from_dict(item)
            except (KeyError, TypeError, ValueError) as exc:
                skipped += 1
                self.notes.append(f"Skipped record #{index}: {exc if str(exc) else 'invalid'}")
                continue
            if donation.id in seen:
                donation.id = max(seen | {d.id for d in donations}) + 1
                self.notes.append(f"Record #{index} reused an ID, so it was renumbered to {donation.id}.")
            seen.add(donation.id)
            donations.append(donation)
        if skipped:
            backup = self.backup("partial")
            self.notes.append(f"Original file saved as {backup.name} before cleaning.")
            self.save(donations)
        return donations

    def _recover(self, reason: str) -> list[Donation]:
        backup = self.backup("corrupt")
        self.notes.append(f"The data file was unreadable ({reason}).")
        if backup:
            self.notes.append(f"A copy was kept as {backup.name} and a clean ledger was started.")
        self._write_template()
        return []

    # ------------------------------------------------------------- saving
    def save(self, donations: list[Donation]) -> None:
        payload = {
            "schema_version": SCHEMA_VERSION,
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "donations": [d.to_dict() for d in donations],
        }
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=self.path.parent, prefix=".ledger-", suffix=".tmp")
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as handle:
                    json.dump(payload, handle, indent=2, ensure_ascii=False)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(tmp, self.path)  # atomic: never leaves a half-written file
            except BaseException:
                if os.path.exists(tmp):
                    os.unlink(tmp)
                raise
        except OSError as exc:
            raise StorageError(f"Could not save to {self.path}: {exc}") from exc

    def _write_template(self) -> None:
        try:
            self.save([])
        except StorageError as exc:
            self.notes.append(str(exc))

    def backup(self, label: str = "backup") -> Path | None:
        """Copy the current data file next to itself. Returns the new path."""
        if not self.path.exists():
            return None
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        target = self.path.with_name(f"{self.path.stem}.{label}-{stamp}{self.path.suffix}")
        try:
            shutil.copy2(self.path, target)
        except OSError:
            return None
        return target
