"""Charity Donation Ledger - record donations by cause and report on them."""

__version__ = "1.0.0"
