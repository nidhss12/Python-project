"""Bulk CSV import with header checks and a row-by-row error log."""
from __future__ import annotations

import csv
import io
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import TextIO

from . import config as cfg
from . import validation as v
from .engine import Ledger

MAX_ROWS = 50_000
MAX_BYTES = 5 * 1024 * 1024
REQUIRED = ["date", "donor_name", "cause", "amount"]
OPTIONAL = ["payment_method", "notes"]
ALIASES = {
    "donor": "donor_name", "name": "donor_name", "donorname": "donor_name",
    "category": "cause", "fund": "cause",
    "value": "amount", "sum": "amount",
    "method": "payment_method", "payment": "payment_method", "paymentmethod": "payment_method",
    "note": "notes", "comment": "notes", "comments": "notes",
    "donation_date": "date",
}


@dataclass
class RowIssue:
    line: int
    field: str
    message: str
    raw: str = ""


@dataclass
class ImportResult:
    source: str
    total_rows: int = 0
    imported: int = 0
    skipped: int = 0
    errors: list[RowIssue] = field(default_factory=list)
    warnings: list[RowIssue] = field(default_factory=list)
    fatal: str | None = None
    log_path: Path | None = None

    @property
    def ok(self) -> bool:
        return self.fatal is None


def _norm(name: str | None) -> str:
    key = (name or "").strip().lower().replace(" ", "_").replace("-", "_")
    return ALIASES.get(key, key)


def import_csv(path: str | Path, ledger: Ledger, error_log: str | Path | None = None) -> ImportResult:
    """Import a CSV file from disk. Never raises for bad files; see result.fatal."""
    path = Path(str(path).strip().strip('"').strip("'")).expanduser()
    result = ImportResult(source=str(path))
    try:
        if not path.is_file():
            raise FileNotFoundError
        if path.stat().st_size > MAX_BYTES:
            result.fatal = f"File is larger than {MAX_BYTES // (1024 * 1024)} MB."
            return _finish(result, error_log)
        text = path.read_text(encoding="utf-8-sig")
    except FileNotFoundError:
        result.fatal = f"File not found: {path}"
        return _finish(result, error_log)
    except UnicodeDecodeError:
        result.fatal = "File is not UTF-8 text. Re-save it as 'CSV UTF-8' and try again."
        return _finish(result, error_log)
    except OSError as exc:
        result.fatal = f"Could not read the file: {exc}"
        return _finish(result, error_log)
    return import_text(text, ledger, source=path.name, error_log=error_log)


def import_text(text: str, ledger: Ledger, source: str = "upload",
                error_log: str | Path | None = None) -> ImportResult:
    return import_stream(io.StringIO(text.lstrip("\ufeff")), ledger, source, error_log)


def import_stream(stream: TextIO, ledger: Ledger, source: str = "upload",
                  error_log: str | Path | None = None) -> ImportResult:
    result = ImportResult(source=source)
    try:
        reader = csv.DictReader(stream)
        headers = reader.fieldnames
    except csv.Error as exc:
        result.fatal = f"This does not look like a CSV file ({exc})."
        return _finish(result, error_log)
    if not headers:
        result.fatal = "The file is empty or has no header row."
        return _finish(result, error_log)

    mapping = {original: _norm(original) for original in headers if original is not None}
    missing = [col for col in REQUIRED if col not in mapping.values()]
    if missing:
        result.fatal = (f"Missing required column(s): {', '.join(missing)}. "
                        f"Found: {', '.join(h for h in headers if h)}. "
                        f"Expected: {', '.join(REQUIRED + OPTIONAL)}.")
        return _finish(result, error_log)

    existing = {(d.date, d.donor_name.lower(), d.cause, d.amount) for d in ledger.donations}
    good: list[dict] = []
    try:
        for row in reader:
            result.total_rows += 1
            line = reader.line_num
            if result.total_rows > MAX_ROWS:
                result.fatal = f"More than {MAX_ROWS:,} rows. Split the file and import it in parts."
                break
            cells = {mapping[k]: (val or "").strip() for k, val in row.items()
                     if k is not None and isinstance(val, (str, type(None)))}
            raw_line = ", ".join(str(x) for x in row.values() if x is not None)[:120]
            if not any(cells.values()) and None not in row:
                result.total_rows -= 1
                result.warnings.append(RowIssue(line, "-", "Blank row ignored.", raw_line))
                continue
            problems = _check_row(cells, row, line, raw_line)
            if problems:
                result.skipped += 1
                result.errors.extend(problems)
                continue
            clean = _clean_row(cells, result, line, raw_line)
            key = (clean["date"], clean["donor_name"].lower(), clean["cause"], clean["amount"])
            if key in existing:
                result.warnings.append(RowIssue(
                    line, "row", "Looks like a duplicate of an existing entry (imported anyway).", raw_line))
            existing.add(key)
            if clean["amount"] >= cfg.LARGE_GIFT_LIMIT:
                result.warnings.append(RowIssue(
                    line, "amount", f"Large gift of {cfg.money(clean['amount'])}. Please confirm.", raw_line))
            good.append(clean)
    except csv.Error as exc:
        result.fatal = f"CSV parsing stopped near line {stream_line(reader)}: {exc}"
    except UnicodeDecodeError:
        result.fatal = "File is not UTF-8 text. Re-save it as 'CSV UTF-8' and try again."

    if result.fatal is None and good:
        ledger.add_many(good)
        result.imported = len(good)
    return _finish(result, error_log)


def stream_line(reader) -> int:
    return getattr(reader, "line_num", 0)


def _check_row(cells: dict, row: dict, line: int, raw: str) -> list[RowIssue]:
    issues: list[RowIssue] = []
    if None in row:
        issues.append(RowIssue(line, "row", "Too many columns. Check for an unquoted comma.", raw))
    checks = [("date", v.validate_date), ("donor_name", v.validate_name),
              ("cause", v.validate_cause), ("amount", v.validate_amount)]
    for name, fn in checks:
        try:
            fn(cells.get(name, ""))
        except v.ValidationError as exc:
            issues.append(RowIssue(line, name, str(exc), raw))
    try:
        v.validate_notes(cells.get("notes", ""))
    except v.ValidationError as exc:
        issues.append(RowIssue(line, "notes", str(exc), raw))
    return issues


def _clean_row(cells: dict, result: ImportResult, line: int, raw: str) -> dict:
    method = cells.get("payment_method", "")
    try:
        method = v.validate_payment(method) if method else "Other"
    except v.ValidationError:
        result.warnings.append(RowIssue(
            line, "payment_method", f"Unknown payment method '{method}', saved as 'Other'.", raw))
        method = "Other"
    return {
        "date": v.validate_date(cells["date"]),
        "donor_name": v.validate_name(cells["donor_name"]),
        "cause": v.validate_cause(cells["cause"]),
        "amount": v.validate_amount(cells["amount"]),
        "payment_method": method,
        "notes": v.validate_notes(cells.get("notes", "")),
    }


def render_log(result: ImportResult) -> str:
    lines = [
        f"Import log - {datetime.now():%Y-%m-%d %H:%M:%S}",
        f"Source        : {result.source}",
        f"Rows read     : {result.total_rows}",
        f"Rows imported : {result.imported}",
        f"Rows skipped  : {result.skipped}",
        f"Warnings      : {len(result.warnings)}",
    ]
    if result.fatal:
        lines += ["", f"IMPORT STOPPED: {result.fatal}"]
    if result.errors:
        lines += ["", "ERRORS (these rows were NOT imported)", "-" * 60]
        lines += [f"line {i.line:>4} | {i.field:<14} | {i.message}\n          raw: {i.raw}"
                  for i in result.errors]
    if result.warnings:
        lines += ["", "WARNINGS (these rows were imported or ignored)", "-" * 60]
        lines += [f"line {i.line:>4} | {i.field:<14} | {i.message}" for i in result.warnings]
    return "\n".join(lines) + "\n"


def _finish(result: ImportResult, error_log: str | Path | None) -> ImportResult:
    if error_log is not None:
        try:
            log = Path(error_log)
            log.parent.mkdir(parents=True, exist_ok=True)
            log.write_text(render_log(result), encoding="utf-8")
            result.log_path = log
        except OSError:
            result.log_path = None
    return result
