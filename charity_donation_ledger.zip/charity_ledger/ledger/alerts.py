"""Threshold warning indicators: large gifts, outliers, duplicates, drops and quiet spells."""
from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from datetime import date

from . import config as cfg
from .config import money
from .models import Donation
from .reports import build_summary

ORDER = {"critical": 0, "warning": 1, "info": 2}


@dataclass
class Alert:
    level: str            # critical | warning | info
    title: str
    detail: str
    ids: list[int] = field(default_factory=list)


def find_alerts(donations: list[Donation], today: date | None = None) -> list[Alert]:
    today = today or date.today()
    if not donations:
        return []
    alerts: list[Alert] = []
    amounts = [d.amount for d in donations]

    # 1. Large gifts and statistical outliers
    mean = statistics.fmean(amounts)
    stdev = statistics.pstdev(amounts) if len(amounts) >= 8 else 0.0
    for d in donations:
        z = (d.amount - mean) / stdev if stdev else 0.0
        big = d.amount >= cfg.LARGE_GIFT_LIMIT
        odd = z > cfg.OUTLIER_Z
        if big or odd:
            why = []
            if big:
                why.append(f"at or above the {money(cfg.LARGE_GIFT_LIMIT)} review limit")
            if odd:
                why.append(f"statistically unusual (z = {z:.1f})")
            level = "critical" if odd else "warning"
            alerts.append(Alert(level, f"Large gift #{d.id}",
                                f"{money(d.amount)} from {d.donor_name} on {d.date} is {' and '.join(why)}.",
                                [d.id]))

    # 2. Very small gifts
    tiny = [d for d in donations if d.amount < 2]
    if tiny:
        alerts.append(Alert("info", "Very small gifts",
                            f"{len(tiny)} gift(s) under {money(2)}: IDs {', '.join(str(d.id) for d in tiny)}. "
                            "Check these are not typos.", [d.id for d in tiny]))

    # 3. Duplicate-looking entries
    seen: dict[tuple, list[Donation]] = {}
    for d in donations:
        seen.setdefault((d.date, d.donor_name.lower(), d.cause, d.amount), []).append(d)
    for group in seen.values():
        if len(group) > 1:
            ids = [d.id for d in group]
            g = group[0]
            alerts.append(Alert("warning", "Possible duplicate",
                                f"{len(group)} identical entries ({money(g.amount)}, {g.donor_name}, "
                                f"{g.cause}, {g.date}): IDs {', '.join(map(str, ids))}.", ids))

    # 4. Causes with a very small share
    if len(donations) >= 20:
        summary = build_summary(donations, today)
        low = [r for r in summary["by_cause"] if r["share"] < cfg.LOW_SHARE_PCT]
        if low:
            names = ", ".join(f"{r['cause']} ({r['share']:.1f}%)" for r in low)
            alerts.append(Alert("info", "Under-funded causes",
                                f"Below {cfg.LOW_SHARE_PCT:.0f}% of total giving: {names}."))
        # 5. Month-over-month drop
        mom = summary.get("mom_change_pct")
        if mom is not None and mom <= -cfg.DROP_ALERT_PCT:
            alerts.append(Alert("warning", "Giving dropped last month",
                                f"The last full month fell {abs(mom):.0f}% compared with the month before."))

    # 6. Quiet spell
    latest = max(date.fromisoformat(d.date) for d in donations)
    gap = (today - latest).days
    if gap > cfg.QUIET_DAYS:
        alerts.append(Alert("warning", "No recent donations",
                            f"The last gift was {gap} days ago ({latest.isoformat()})."))

    # 7. Future-dated entries (possible after hand-editing the file)
    future = [d for d in donations if d.date > today.isoformat()]
    if future:
        alerts.append(Alert("warning", "Future-dated entries",
                            f"IDs {', '.join(str(d.id) for d in future)} have dates after today.",
                            [d.id for d in future]))

    return sorted(alerts, key=lambda a: ORDER[a.level])
