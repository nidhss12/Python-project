"""Business logic: record, edit, delete and search donations."""
from __future__ import annotations

from typing import Any, Iterable

from . import validation as v
from .models import Donation
from .storage import Storage


class NotFound(LookupError):
    pass


class Ledger:
    def __init__(self, storage: Storage | None = None):
        self.storage = storage or Storage()
        self.donations: list[Donation] = self.storage.load()

    # ----------------------------------------------------------- helpers
    @property
    def load_notes(self) -> list[str]:
        return self.storage.notes

    def reload(self) -> None:
        self.donations = self.storage.load()

    def _next_id(self) -> int:
        return max((d.id for d in self.donations), default=0) + 1

    def _build(self, data: dict, donation_id: int) -> Donation:
        return Donation(
            id=donation_id,
            date=v.validate_date(data.get("date")),
            donor_name=v.validate_name(data.get("donor_name")),
            cause=v.validate_cause(data.get("cause")),
            amount=v.validate_amount(data.get("amount")),
            payment_method=v.validate_payment(data.get("payment_method") or "Other"),
            notes=v.validate_notes(data.get("notes") or ""),
        )

    # -------------------------------------------------------------- CRUD
    def add(self, date: Any, donor_name: Any, cause: Any, amount: Any,
            payment_method: Any = "Other", notes: Any = "") -> Donation:
        """Validate and record one donation. Raises ValidationError on bad input."""
        donation = self._build(
            {"date": date, "donor_name": donor_name, "cause": cause, "amount": amount,
             "payment_method": payment_method, "notes": notes},
            self._next_id(),
        )
        self.donations.append(donation)
        self.storage.save(self.donations)
        return donation

    def add_many(self, records: Iterable[dict]) -> list[Donation]:
        """Record many already-checked rows with a single save."""
        added = []
        next_id = self._next_id()
        for rec in records:
            added.append(self._build(rec, next_id))
            next_id += 1
        self.donations.extend(added)
        self.storage.save(self.donations)
        return added

    def get(self, donation_id: Any) -> Donation:
        wanted = v.validate_id(donation_id)
        for d in self.donations:
            if d.id == wanted:
                return d
        raise NotFound(f"No donation with ID {wanted}.")

    def edit(self, donation_id: Any, **changes: Any) -> Donation:
        current = self.get(donation_id)
        merged = current.to_dict()
        merged.update({k: val for k, val in changes.items() if k in merged and k != "id"})
        updated = self._build(merged, current.id)
        self.donations[self.donations.index(current)] = updated
        self.storage.save(self.donations)
        return updated

    def delete(self, donation_id: Any) -> Donation:
        target = self.get(donation_id)
        self.donations.remove(target)
        self.storage.save(self.donations)
        return target

    def clear(self) -> None:
        self.storage.backup("before-clear")
        self.donations = []
        self.storage.save(self.donations)

    # ------------------------------------------------------------ search
    def search(
        self,
        keyword: str = "",
        causes: str | Iterable[str] | None = None,
        payment_methods: str | Iterable[str] | None = None,
        date_from: Any = None,
        date_to: Any = None,
        min_amount: Any = None,
        max_amount: Any = None,
        sort: str = "date",
        descending: bool = True,
    ) -> list[Donation]:
        """Combine keyword, category, date-range and amount-range filters."""
        cause_set = _as_set(causes, v.validate_cause)
        method_set = _as_set(payment_methods, v.validate_payment)
        start = v.validate_date(date_from, allow_future=True) if date_from else None
        end = v.validate_date(date_to, allow_future=True) if date_to else None
        if start and end and start > end:
            raise v.ValidationError("The start date is after the end date.")
        low = _amount_or_none(min_amount)
        high = _amount_or_none(max_amount)
        if low is not None and high is not None and low > high:
            raise v.ValidationError("The minimum amount is higher than the maximum.")
        words = [w for w in (keyword or "").lower().split() if w]

        def keep(d: Donation) -> bool:
            if cause_set and d.cause not in cause_set:
                return False
            if method_set and d.payment_method not in method_set:
                return False
            if start and d.date < start:
                return False
            if end and d.date > end:
                return False
            if low is not None and d.amount < low:
                return False
            if high is not None and d.amount > high:
                return False
            if words:
                haystack = " ".join(
                    [d.donor_name, d.cause, d.notes, d.payment_method, d.date, str(d.id)]
                ).lower()
                return all(w in haystack for w in words)  # every word must match
            return True

        keys = {
            "date": lambda d: (d.date, d.id),
            "amount": lambda d: (d.amount, d.id),
            "donor": lambda d: (d.donor_name.lower(), d.id),
            "cause": lambda d: (d.cause, d.id),
            "id": lambda d: d.id,
        }
        return sorted((d for d in self.donations if keep(d)), key=keys.get(sort, keys["date"]),
                      reverse=descending)

    def totals_by_cause(self) -> dict[str, float]:
        totals: dict[str, float] = {}
        for d in self.donations:
            totals[d.cause] = round(totals.get(d.cause, 0.0) + d.amount, 2)
        return dict(sorted(totals.items(), key=lambda kv: kv[1], reverse=True))


def _as_set(values, validator) -> set[str]:
    if not values:
        return set()
    if isinstance(values, str):
        values = [values]
    return {validator(x) for x in values}


def _amount_or_none(value: Any):
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except ValueError:
        raise v.ValidationError(f"'{value}' is not a valid amount for the filter.") from None
