# Charity Donation Ledger

Record donations by cause and get an instant summary report. Built for the FutureReady Hack
(Project #19, Finance & Personal Management).

Two front ends share one tested backend:

| | Command | Needs |
|---|---|---|
| Terminal app (the brief's core requirement) | `python main.py` | Python 3.10+, nothing else |
| Streamlit web app (modern GUI) | `streamlit run app.py` | `pip install -r requirements.txt` |

Charts need Matplotlib. If it is missing, the terminal app still runs and tells you what to install.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python main.py                     # terminal app
streamlit run app.py               # web app
python -m unittest discover -s tests -v   # 25 tests
```

On first launch the terminal app offers to load 40 demo donations. The web app has a
"Load 40 demo donations" button on any empty page.

## Feature checklist (from the brief)

| Brief requirement | Where it lives |
|---|---|
| Interactive terminal interface | `ledger/cli.py`: branded welcome, numbered menu, ANSI colour, guided prompts |
| Defensive input validation | `ledger/validation.py`: one validator per field plus a loop wrapper (`prompt_until_valid`) that never crashes on blank, wrong-type or out-of-range input. `/cancel`, Ctrl+C and Ctrl+D go back to the menu |
| Core business logic | `ledger/engine.py`: record, edit, delete, totals by cause |
| Local data persistence | `ledger/storage.py`: JSON, atomic writes, schema checks. Missing, empty or corrupted files are backed up and replaced with a clean template |
| Record query and search | `Ledger.search()`: keyword (every word must match), cause, payment method, date range, amount range, sorting |
| Executive summary | `ledger/reports.py`: total, count, average, median, largest/smallest, per-cause share, top donors, monthly trend, status indicator (Growing / Steady / Declining) |
| Visual data plotting | `ledger/charts.py`: monthly trend, cause bars, cause share donut, top donors |
| Multi-format export (stretch) | Markdown report, plain-text audit log, summary CSV, full donations CSV, plus PNG charts |
| Threshold warnings (stretch) | `ledger/alerts.py`: large gifts, statistical outliers, duplicates, tiny gifts, under-funded causes, month-over-month drops, quiet spells, future dates |
| TUI / GUI enhancement (stretch) | `app.py`: Streamlit with Dashboard, Add donation, Records, Reports & charts, Import, Export |
| Bulk dataset import (stretch) | `ledger/importer.py`: header checks, column aliases, row-by-row error log |

## Demo script (about 4 minutes)

1. `python main.py` and accept the demo data. Point out the welcome screen and menu.
2. **Record a donation** (option 1). Deliberately type `2026-13-45`, a future date, `!!!` as the name, `abc` and `-5` as the amount, and watch each get rejected with a fix-it message. Then enter valid values.
3. **Executive summary** (option 6) for tables, share bars, the monthly trend and the warning flags (a 25,000 outlier, a duplicate and a 51% monthly drop are seeded).
4. **Search & filter** (option 3): keyword `rotary`, or cause Health with a minimum of 400.
5. **Import** (option 10) with `data/bad_import_example.csv`. Three rows import, seven are skipped with a line-by-line explanation, and a full log is written to `exports/`.
6. **Persistence**: exit, relaunch, and the new record is still there.
7. **Export** (option 9) writes Markdown, audit log, CSVs and four charts to `exports/report_<timestamp>/`.
8. Finish with `streamlit run app.py` to show the dashboard.

## Project layout

```
main.py                  terminal entry point (options: --data FILE, --no-color)
app.py                   Streamlit GUI
ledger/
  config.py              paths, limits, thresholds, causes, colours
  models.py              Donation dataclass
  validation.py          validators + prompt loop
  storage.py             JSON persistence and recovery
  engine.py              CRUD and search
  reports.py             summary maths and exports
  alerts.py              warning indicators
  charts.py              Matplotlib charts
  importer.py            CSV bulk import
  cli.py                 terminal UI
data/                    sample_donations.json/.csv (40 rows), bad_import_example.csv
exports/                 generated reports, charts, import logs
scripts/make_sample_data.py   regenerates the sample files
tests/test_ledger.py     25 unit tests (standard library only)
.streamlit/config.toml   GUI theme
```

## Configuration

* **Currency symbol**: set `LEDGER_CURRENCY` (for example `LEDGER_CURRENCY="Rs "` or `"EUR "`).
* **Data file**: set `LEDGER_DATA=/path/to/file.json`, or pass `--data` to the terminal app.
* **Limits and thresholds** (maximum amount, large-gift limit, drop percentage and so on) are in `ledger/config.py`.
* **Causes and payment methods** are lists in `ledger/config.py`; add a colour for any new cause in `CAUSE_COLORS`.

## Data format

`data/donations.json`:

```json
{
  "schema_version": 1,
  "donations": [
    {"id": 1, "date": "2026-01-05", "donor_name": "Aarav Sharma", "cause": "Education",
     "amount": 250.0, "payment_method": "UPI", "notes": "New year scholarship fund"}
  ]
}
```

CSV import needs `date, donor_name, cause, amount`. `payment_method` and `notes` are optional.
Common alternative headers such as `donor`, `category`, `value` and `note` are recognised.

## Safety notes

* Writes are atomic (temp file then rename), so a crash mid-save cannot corrupt the ledger.
* Before any file is replaced because it was corrupt, partly invalid, or cleared, a timestamped backup is kept next to it.
* Text that starts with `= + - @` is prefixed with an apostrophe in exported CSVs so spreadsheet apps do not run it as a formula, and donor names must start with a letter.
