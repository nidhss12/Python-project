"""Streamlit GUI:  streamlit run app.py"""
from __future__ import annotations

import html
from datetime import date, datetime

import pandas as pd
import streamlit as st

from ledger import alerts as alerts_mod
from ledger import charts, importer, reports
from ledger import config as cfg
from ledger import validation as v
from ledger.config import money
from ledger.engine import Ledger, NotFound
from ledger.storage import StorageError

PAGES = ["Dashboard", "Add donation", "Records", "Reports & charts", "Import", "Export"]
LEVEL_COLOR = {"critical": "#D1495B", "warning": "#EDAE49", "info": "#2F6F8F"}
STATUS_COLOR = {"Growing": "#7FD1A0", "Declining": "#F08A8A", "Steady": "#F2C46B"}

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,700&family=Manrope:wght@400;500;600;700&display=swap');
html, body, .stApp, [data-testid="stMarkdownContainer"], button, input, textarea, select {
  font-family: 'Manrope', system-ui, -apple-system, 'Segoe UI', sans-serif; }
h1, h2, h3, .serif { font-family: 'Fraunces', Georgia, 'Times New Roman', serif !important;
  color: #16403A; letter-spacing: -0.01em; }
.block-container { padding-top: 2.4rem; padding-bottom: 4rem; max-width: 1160px; }
#MainMenu, footer { visibility: hidden; }
header[data-testid="stHeader"] { background: transparent; }

[data-testid="stSidebar"] { background: #16403A; }
[data-testid="stSidebar"] * { color: #E4EEEA; }
[data-testid="stSidebar"] label p { font-size: 1rem; font-weight: 500; }
.brand { font-family: 'Fraunces', Georgia, serif; font-size: 1.55rem; line-height: 1.15;
  font-weight: 700; color: #FFFFFF; margin: 0.4rem 0 0.2rem; }
.tagline { color: #9FBFB5; font-size: 0.9rem; margin-bottom: 1.4rem; }
.side-foot { color: #9FBFB5; font-size: 0.82rem; margin-top: 2rem; }

.page-title { font-family: 'Fraunces', Georgia, serif; font-size: 2.3rem; font-weight: 700;
  color: #16403A; margin: 0 0 0.15rem; line-height: 1.1; }
.page-sub { color: #52665F; margin-bottom: 1.4rem; max-width: 62ch; }

.hero { background: #16403A; color: #FFFFFF; border-radius: 20px; padding: 28px 32px 26px; }
.hero-top { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; flex-wrap: wrap; }
.hero .label { font-size: 0.92rem; color: #B7D1C9; }
.hero .amount { font-family: 'Fraunces', Georgia, serif; font-weight: 700; color: #FFFFFF;
  font-size: clamp(2.5rem, 6vw, 4rem); line-height: 1.05; margin: 0.25rem 0 1.2rem;
  font-variant-numeric: lining-nums tabular-nums; }
.badge { border-radius: 999px; padding: 6px 14px; font-weight: 600; font-size: 0.88rem;
  background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.25); white-space: nowrap; }
.ribbon { display: flex; gap: 3px; height: 18px; border-radius: 9px; overflow: hidden; }
.ribbon span { display: block; height: 100%; }
.legend { display: flex; flex-wrap: wrap; gap: 8px 20px; margin-top: 16px; font-size: 0.84rem; color: #D6E6E0; }
.legend i { display: inline-block; width: 10px; height: 10px; border-radius: 50%; margin-right: 7px; }

.strip { display: flex; flex-wrap: wrap; margin: 20px 0 10px; }
.strip > div { box-sizing: border-box; flex: 1 1 0; min-width: 150px; padding: 6px 18px; border-left: 1px solid #C9D7D2; }
.strip > div:first-child { border-left: 0; padding-left: 2px; }
.strip b { display: block; font-family: 'Fraunces', Georgia, serif; font-size: 1.6rem; color: #16403A;
  font-variant-numeric: lining-nums tabular-nums; }
.strip span { font-size: 0.85rem; color: #5A6E68; }

.section { font-family: 'Fraunces', Georgia, serif; font-size: 1.45rem; font-weight: 700;
  color: #16403A; margin: 2rem 0 0.6rem; }
.alert { display: flex; gap: 14px; padding: 11px 0; border-bottom: 1px solid #D8E2DE; }
.alert .dot { width: 11px; height: 11px; border-radius: 50%; margin-top: 6px; flex: none; }
.alert b { display: block; color: #16322D; }
.alert span { color: #52665F; font-size: 0.93rem; }
.empty { border: 1.5px dashed #A9BDB6; border-radius: 16px; padding: 30px 28px; color: #3F544E; background: #FBFDFC; }
.empty b { font-family: 'Fraunces', Georgia, serif; font-size: 1.3rem; color: #16403A; display: block; margin-bottom: 4px; }

div[data-testid="stForm"] { background: #FFFFFF; border: 1px solid #D5E0DB; border-radius: 16px; padding: 22px 24px; }
div.stButton > button, div[data-testid="stFormSubmitButton"] > button, div.stDownloadButton > button {
  border-radius: 10px; font-weight: 600; border: 1px solid #16403A; }
div[data-testid="stFormSubmitButton"] > button { background: #16403A; color: #FFFFFF; }
div[data-testid="stFormSubmitButton"] > button:hover { background: #0F2D29; color: #FFFFFF; border-color: #0F2D29; }
*:focus-visible { outline: 3px solid #F2A93B !important; outline-offset: 2px; }
</style>
"""


# ---------------------------------------------------------------- helpers
def esc(x) -> str:
    return html.escape(str(x))


def page_header(title: str, sub: str = "") -> None:
    st.markdown(f'<div class="page-title">{esc(title)}</div><div class="page-sub">{esc(sub)}</div>',
                unsafe_allow_html=True)


def section(title: str) -> None:
    st.markdown(f'<div class="section">{esc(title)}</div>', unsafe_allow_html=True)


def flash(kind: str, message: str) -> None:
    st.session_state["_flash"] = (kind, message)


def show_flash() -> None:
    if "_flash" in st.session_state:
        kind, message = st.session_state.pop("_flash")
        getattr(st, kind)(message)


def show_table(df: pd.DataFrame, **kwargs) -> None:
    """Render a dataframe full-width, whichever Streamlit version is installed."""
    try:
        st.dataframe(df, width="stretch", hide_index=True, **kwargs)
    except Exception:
        st.dataframe(df, use_container_width=True, hide_index=True, **kwargs)


def to_df(rows) -> pd.DataFrame:
    return pd.DataFrame([{"ID": d.id, "Date": d.date, "Donor": d.donor_name, "Cause": d.cause,
                          "Amount": d.amount, "Method": d.payment_method, "Notes": d.notes}
                         for d in rows])


def amount_config() -> dict:
    return {"Amount": st.column_config.NumberColumn("Amount", format=f"{cfg.CURRENCY}%.2f")}


def empty_state(ledger: Ledger, message: str) -> None:
    st.markdown(f'<div class="empty"><b>Nothing here yet</b>{esc(message)}</div>', unsafe_allow_html=True)
    if st.button("Load 40 demo donations", key=f"demo_{message[:12]}"):
        result = importer.import_csv(cfg.SAMPLE_CSV, ledger)
        flash("success", f"Loaded {result.imported} demo donations.")
        st.rerun()


def show_alert_list(found) -> None:
    if not found:
        st.success("No warnings. Everything looks normal.")
        return
    rows = "".join(
        f'<div class="alert"><div class="dot" style="background:{LEVEL_COLOR[a.level]}"></div>'
        f'<div><b>{esc(a.title)}</b><span>{esc(a.detail)}</span></div></div>' for a in found)
    st.markdown(rows, unsafe_allow_html=True)


def show_chart(name: str, summary: dict, key: str, download: bool = False) -> None:
    fig = charts.CHARTS[name](summary)
    st.pyplot(fig)
    if download:
        st.download_button("Download PNG", charts.to_png_bytes(fig), file_name=f"{name}.png",
                           mime="image/png", key=f"dl_{key}")


# ------------------------------------------------------------------ pages
def page_dashboard(ledger: Ledger) -> None:
    page_header("Dashboard", "Where your donations stand, by cause and over time.")
    if not ledger.donations:
        empty_state(ledger, "Record your first donation, or load the demo data to explore the dashboard.")
        return
    s = reports.build_summary(ledger.donations)
    segments = "".join(
        f'<span title="{esc(r["cause"])} {r["share"]:.1f}%" '
        f'style="flex:{max(r["share"], 0.5):.2f} 1 0;min-width:6px;background:{cfg.CAUSE_COLORS.get(r["cause"], "#8A9A9E")}"></span>'
        for r in s["by_cause"])
    legend = "".join(
        f'<span><i style="background:{cfg.CAUSE_COLORS.get(r["cause"], "#8A9A9E")}"></i>'
        f'{esc(r["cause"])} {r["share"]:.0f}%</span>' for r in s["by_cause"])
    badge_color = STATUS_COLOR.get(s["status"], "#F2C46B")
    st.markdown(f"""
    <div class="hero">
      <div class="hero-top">
        <div><div class="label">Total raised, {esc(s['first_date'])} to {esc(s['last_date'])}</div>
        <div class="amount">{esc(money(s['total']))}</div></div>
        <div class="badge" style="color:{badge_color}" title="{esc(s['status_note'])}">{esc(s['status'])}</div>
      </div>
      <div class="ribbon">{segments}</div>
      <div class="legend">{legend}</div>
    </div>
    <div class="strip">
      <div><b>{s['count']}</b><span>donations</span></div>
      <div><b>{s['unique_donors']}</b><span>donors</span></div>
      <div><b>{esc(money(s['average']))}</b><span>average gift</span></div>
      <div><b>{esc(money(s['median']))}</b><span>median gift</span></div>
      <div><b>{esc(money(s['largest'].amount))}</b><span>largest gift</span></div>
    </div>""", unsafe_allow_html=True)
    st.caption(s["status_note"])

    found = alerts_mod.find_alerts(ledger.donations)
    section("Needs a look" if found else "Warnings")
    show_alert_list(found[:4])
    if len(found) > 4:
        with st.expander(f"Show {len(found) - 4} more"):
            show_alert_list(found[4:])

    section("Trends")
    if not charts.AVAILABLE:
        st.info("Install Matplotlib to see charts:  pip install matplotlib")
        return
    left, right = st.columns([3, 2])
    with left:
        show_chart("monthly_trend", s, "dash_trend")
    with right:
        show_chart("cause_share", s, "dash_share")
    left, right = st.columns(2)
    with left:
        show_chart("cause_bar", s, "dash_bar")
    with right:
        show_chart("top_donors", s, "dash_top")


def page_add(ledger: Ledger) -> None:
    page_header("Add donation", "Record a gift against a cause. Every field is checked before it is saved.")
    show_flash()
    n = st.session_state.setdefault("add_counter", 0)
    today = date.today()
    with st.form(f"add_form_{n}"):
        c1, c2 = st.columns(2)
        when = c1.date_input("Date", value=today, min_value=date(cfg.MIN_DATE_YEAR, 1, 1),
                             max_value=today, key=f"add_date_{n}")
        donor = c2.text_input("Donor name", placeholder="Maria Gonzalez, or Anonymous", key=f"add_donor_{n}")
        c3, c4 = st.columns(2)
        cause = c3.selectbox("Cause", cfg.CAUSES, key=f"add_cause_{n}")
        amount = c4.text_input(f"Amount ({cfg.CURRENCY.strip()})", placeholder="250.00", key=f"add_amount_{n}")
        c5, c6 = st.columns(2)
        method = c5.selectbox("Payment method", cfg.PAYMENT_METHODS, key=f"add_method_{n}")
        notes = c6.text_input("Notes (optional)", key=f"add_notes_{n}", max_chars=cfg.MAX_NOTES_LEN)
        submitted = st.form_submit_button("Save donation")
    if submitted:
        try:
            saved = ledger.add(when, donor, cause, amount, method, notes)
        except v.ValidationError as exc:
            st.error(str(exc))
        except StorageError as exc:
            st.error(f"Could not save: {exc}")
        else:
            total = ledger.totals_by_cause().get(saved.cause, 0)
            msg = f"Saved donation #{saved.id}. {saved.cause} has now raised {money(total)}."
            if saved.amount >= cfg.LARGE_GIFT_LIMIT:
                msg += f" This is a large gift (review limit {money(cfg.LARGE_GIFT_LIMIT)}): please double-check it."
            flash("success", msg)
            st.session_state["add_counter"] = n + 1
            st.rerun()
    recent = ledger.search(sort="id")[:5]
    if recent:
        section("Latest entries")
        show_table(to_df(recent), column_config=amount_config())


def page_records(ledger: Ledger) -> None:
    page_header("Records", "Search by keyword, cause, method, date or amount. Edit or delete below.")
    show_flash()
    if not ledger.donations:
        empty_state(ledger, "No records to search. Add a donation or load the demo data.")
        return
    dates = sorted(d.date for d in ledger.donations)
    first, last = date.fromisoformat(dates[0]), date.fromisoformat(dates[-1])
    with st.expander("Filters", expanded=True):
        c1, c2, c3 = st.columns(3)
        keyword = c1.text_input("Keyword", placeholder="donor, notes, cause...")
        causes = c2.multiselect("Cause", cfg.CAUSES)
        methods = c3.multiselect("Payment method", cfg.PAYMENT_METHODS)
        c4, c5, c6 = st.columns(3)
        span = c4.date_input("Date range", value=(first, last), min_value=first, max_value=max(last, date.today()))
        low = c5.text_input("Minimum amount", placeholder="no minimum")
        high = c6.text_input("Maximum amount", placeholder="no maximum")
        c7, c8 = st.columns(2)
        sort = c7.selectbox("Sort by", ["date", "amount", "donor", "cause", "id"])
        newest = c8.selectbox("Order", ["High to low / newest first", "Low to high / oldest first"]) == \
            "High to low / newest first"
    start, end = (span[0], span[1]) if isinstance(span, (tuple, list)) and len(span) == 2 else (None, None)
    try:
        rows = ledger.search(keyword, causes, methods, start, end, low, high, sort, newest)
    except v.ValidationError as exc:
        st.error(str(exc))
        return
    st.markdown(f"**{len(rows)}** of {len(ledger.donations)} records, "
                f"totalling **{esc(money(sum(d.amount for d in rows)))}**")
    if not rows:
        st.info("No records match these filters. Loosen a filter or clear the keyword.")
        return
    show_table(to_df(rows), column_config=amount_config())

    section("Edit or delete")
    labels = {d.id: f"#{d.id}  {d.date}  {d.donor_name}  {money(d.amount)}" for d in rows}
    picked = st.selectbox("Choose a record", list(labels), format_func=labels.get)
    try:
        d = ledger.get(picked)
    except NotFound as exc:
        st.error(str(exc))
        return
    tab_edit, tab_delete = st.tabs(["Edit", "Delete"])
    with tab_edit:
        with st.form(f"edit_form_{d.id}"):
            c1, c2 = st.columns(2)
            new_date = c1.date_input("Date", value=date.fromisoformat(d.date),
                                     min_value=date(cfg.MIN_DATE_YEAR, 1, 1),
                                     max_value=max(date.today(), date.fromisoformat(d.date)), key=f"e_date_{d.id}")
            new_donor = c2.text_input("Donor name", value=d.donor_name, key=f"e_donor_{d.id}")
            c3, c4 = st.columns(2)
            new_cause = c3.selectbox("Cause", cfg.CAUSES, index=cfg.CAUSES.index(d.cause), key=f"e_cause_{d.id}")
            new_amount = c4.text_input("Amount", value=f"{d.amount:.2f}", key=f"e_amount_{d.id}")
            c5, c6 = st.columns(2)
            new_method = c5.selectbox("Payment method", cfg.PAYMENT_METHODS,
                                      index=cfg.PAYMENT_METHODS.index(d.payment_method), key=f"e_method_{d.id}")
            new_notes = c6.text_input("Notes", value=d.notes, key=f"e_notes_{d.id}")
            saved = st.form_submit_button("Save changes")
        if saved:
            try:
                ledger.edit(d.id, date=new_date, donor_name=new_donor, cause=new_cause,
                            amount=new_amount, payment_method=new_method, notes=new_notes)
            except v.ValidationError as exc:
                st.error(str(exc))
            else:
                flash("success", f"Donation #{d.id} updated.")
                st.rerun()
    with tab_delete:
        st.write(f"This permanently removes donation #{d.id}: {money(d.amount)} from {d.donor_name} "
                 f"({d.cause}, {d.date}).")
        sure = st.checkbox("Yes, delete this donation", key=f"del_ok_{d.id}")
        if st.button("Delete donation", key=f"del_btn_{d.id}", disabled=not sure):
            ledger.delete(d.id)
            flash("success", f"Donation #{d.id} deleted.")
            st.rerun()


def page_reports(ledger: Ledger) -> None:
    page_header("Reports & charts", "Totals, averages, trends and warning flags in one place.")
    if not ledger.donations:
        empty_state(ledger, "Reports need at least one donation.")
        return
    s = reports.build_summary(ledger.donations)
    tab_sum, tab_chart, tab_warn = st.tabs(["Summary", "Charts", "Warnings"])
    with tab_sum:
        st.markdown(f"**{esc(s['status'])}.** {esc(s['status_note'])}")
        if s["mom_change_pct"] is not None:
            st.caption(f"Last full month vs the month before: {s['mom_change_pct']:+.1f}%. "
                       f"Best month: {s['best_month']['month']} ({money(s['best_month']['total'])}).")
        section("By cause")
        df = pd.DataFrame([{"Cause": r["cause"], "Total": r["total"], "Gifts": r["count"],
                            "Average": r["average"], "Share": r["share"]} for r in s["by_cause"]])
        show_table(df, column_config={
            "Total": st.column_config.NumberColumn(format=f"{cfg.CURRENCY}%.2f"),
            "Average": st.column_config.NumberColumn(format=f"{cfg.CURRENCY}%.2f"),
            "Share": st.column_config.ProgressColumn("Share of total", format="%.1f%%",
                                                     min_value=0, max_value=100)})
        left, right = st.columns(2)
        with left:
            section("Top donors")
            show_table(pd.DataFrame([{"Donor": r["donor"], "Total": r["total"], "Gifts": r["count"]}
                                     for r in s["top_donors"]]),
                       column_config={"Total": st.column_config.NumberColumn(format=f"{cfg.CURRENCY}%.2f")})
        with right:
            section("Monthly trend")
            show_table(pd.DataFrame([{"Month": m["month"], "Total": m["total"], "Gifts": m["count"]}
                                     for m in s["monthly"]]),
                       column_config={"Total": st.column_config.NumberColumn(format=f"{cfg.CURRENCY}%.2f")})
    with tab_chart:
        if not charts.AVAILABLE:
            st.info("Install Matplotlib to see charts:  pip install matplotlib")
        else:
            for name in charts.CHARTS:
                show_chart(name, s, f"rep_{name}", download=True)
    with tab_warn:
        show_alert_list(alerts_mod.find_alerts(ledger.donations))


def page_import(ledger: Ledger) -> None:
    page_header("Import", "Bring in an older CSV. Bad rows are skipped and explained, good rows are saved.")
    show_flash()
    st.markdown("Required columns: `date`, `donor_name`, `cause`, `amount`. "
                "Optional: `payment_method`, `notes`. Dates use YYYY-MM-DD.")
    template = "date,donor_name,cause,amount,payment_method,notes\n2026-01-15,Jane Doe,Education,100.00,Card,Example row\n"
    st.download_button("Download a CSV template", template, file_name="donation_import_template.csv",
                       mime="text/csv")
    upload = st.file_uploader("Choose a CSV file", type=["csv"])
    c1, c2 = st.columns(2)
    run_upload = c1.button("Import this file", disabled=upload is None)
    run_demo = c2.button("Try the messy demo file")
    result = None
    if run_upload and upload is not None:
        try:
            text = upload.getvalue().decode("utf-8-sig")
        except UnicodeDecodeError:
            st.error("That file is not UTF-8 text. Re-save it as 'CSV UTF-8' in your spreadsheet app and try again.")
        else:
            result = importer.import_text(text, ledger, source=upload.name)
    elif run_demo:
        result = importer.import_csv(cfg.BAD_IMPORT_SAMPLE, ledger)
    if result is None:
        return
    if result.fatal:
        st.error(result.fatal)
    else:
        st.success(f"Imported {result.imported} of {result.total_rows} rows. "
                   f"Skipped {result.skipped}. Warnings: {len(result.warnings)}.")
    if result.errors:
        section("Rows that were not imported")
        show_table(pd.DataFrame([{"Line": i.line, "Field": i.field, "Problem": i.message, "Row": i.raw}
                                 for i in result.errors]))
    if result.warnings:
        section("Warnings")
        show_table(pd.DataFrame([{"Line": i.line, "Field": i.field, "Note": i.message}
                                 for i in result.warnings]))
    st.download_button("Download the row-by-row log", importer.render_log(result),
                       file_name="import_log.txt", mime="text/plain")


def page_export(ledger: Ledger) -> None:
    page_header("Export", "Take your data out as Markdown, a plain-text audit log, or CSV.")
    if not ledger.donations:
        empty_state(ledger, "There is nothing to export yet.")
        return
    s = reports.build_summary(ledger.donations)
    found = alerts_mod.find_alerts(ledger.donations)
    stamp = datetime.now().strftime("%Y%m%d")
    files = [
        ("Markdown report", "Formatted summary for sharing", reports.to_markdown(s, found),
         f"summary_{stamp}.md", "text/markdown"),
        ("Plain-text audit log", "Every record, line by line", reports.audit_log(ledger.donations, s, found),
         f"audit_log_{stamp}.txt", "text/plain"),
        ("Summary CSV", "Cause, donor, method and month totals", reports.summary_csv(s),
         f"summary_{stamp}.csv", "text/csv"),
        ("All donations CSV", "The full ledger for a spreadsheet", reports.donations_csv(ledger.donations),
         f"donations_{stamp}.csv", "text/csv"),
    ]
    for label, helptext, content, name, mime in files:
        c1, c2 = st.columns([3, 1])
        c1.markdown(f"**{label}**  \n{helptext}")
        c2.download_button("Download", content, file_name=name, mime=mime, key=f"dl_{name}")
    section("Save everything to a folder")
    st.write(f"Writes all four files and the charts to `{cfg.EXPORT_DIR}`.")
    if st.button("Save all to the exports folder"):
        written = reports.export_all(ledger.donations, s, found)
        st.success(f"Wrote {len(written)} files to {written[0].parent}")
    with st.expander("Preview the Markdown report"):
        st.markdown(files[0][2])


PAGE_FUNCS = {"Dashboard": page_dashboard, "Add donation": page_add, "Records": page_records,
              "Reports & charts": page_reports, "Import": page_import, "Export": page_export}


def main() -> None:
    st.set_page_config(page_title=cfg.APP_NAME, page_icon="🌱", layout="wide")
    st.markdown(CSS, unsafe_allow_html=True)
    ledger = Ledger()  # re-read each run so the file is always the source of truth
    with st.sidebar:
        st.markdown(f'<div class="brand">{esc(cfg.APP_NAME)}</div><div class="tagline">{esc(cfg.TAGLINE)}</div>',
                    unsafe_allow_html=True)
        page = st.radio("Navigate", PAGES, label_visibility="collapsed", key="nav")
        st.markdown(f'<div class="side-foot">{len(ledger.donations)} donations on file<br>'
                    f'{esc(money(sum(d.amount for d in ledger.donations)))} raised</div>', unsafe_allow_html=True)
    for message in ledger.load_notes:
        if "fresh ledger" not in message:
            st.warning(message)
    PAGE_FUNCS[page](ledger)


if __name__ == "__main__":
    main()
