"""Run with:  python -m unittest discover -s tests -v"""
import json
import os
import sys
import tempfile
import unittest
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ledger import alerts, config as cfg, importer, reports  # noqa: E402
from ledger import validation as v  # noqa: E402
from ledger.engine import Ledger, NotFound  # noqa: E402
from ledger.storage import Storage  # noqa: E402

TODAY = date(2026, 11, 22)


def new_ledger(tmp):
    return Ledger(Storage(os.path.join(tmp, "d.json")))


class ValidationTests(unittest.TestCase):
    def test_amount_good(self):
        self.assertEqual(v.validate_amount("1,250.555"), 1250.56)
        self.assertEqual(v.validate_amount(" $99 "), 99.0)
        self.assertEqual(v.validate_amount(0.01), 0.01)

    def test_amount_bad(self):
        for bad in ["", "abc", "-5", "0", "0.004", "nan", "inf", "1e400", "2000000", True, None]:
            with self.assertRaises(v.ValidationError, msg=repr(bad)):
                v.validate_amount(bad)

    def test_date(self):
        self.assertEqual(v.validate_date("2026-3-5", today=TODAY), "2026-03-05")
        self.assertEqual(v.validate_date("today", today=TODAY), "2026-11-22")
        for bad in ["", "2026-13-01", "01/02/2026", "2026-11-23", "1999-01-01"]:
            with self.assertRaises(v.ValidationError, msg=bad):
                v.validate_date(bad, today=TODAY)
        self.assertEqual(v.validate_date("2099-01-01", allow_future=True), "2099-01-01")

    def test_name(self):
        self.assertEqual(v.validate_name("  Liam   O'Brien "), "Liam O'Brien")
        self.assertEqual(v.validate_name("José Martínez"), "José Martínez")
        for bad in ["", "A", "=SUM(A1)", "123", "x" * 61, "<script>"]:
            with self.assertRaises(v.ValidationError, msg=bad):
                v.validate_name(bad)

    def test_choices(self):
        self.assertEqual(v.validate_cause("2"), "Health")
        self.assertEqual(v.validate_cause("env"), "Environment")
        self.assertEqual(v.validate_cause("HEALTH"), "Health")
        for bad in ["", "0", "99", "charity", "h"]:  # 'h' matches Health + Hunger
            with self.assertRaises(v.ValidationError, msg=bad):
                v.validate_cause(bad)

    def test_prompt_loop_recovers(self):
        answers = iter(["abc", "-1", "42"])
        out = []
        got = v.prompt_until_valid("Amount", v.validate_amount, input_fn=lambda _: next(answers),
                                   print_fn=out.append)
        self.assertEqual(got, 42.0)
        self.assertEqual(len(out), 2)

    def test_prompt_cancel_and_default(self):
        with self.assertRaises(v.InputCancelled):
            v.prompt_until_valid("x", v.validate_amount, input_fn=lambda _: "/cancel")
        def eof(_): raise EOFError
        with self.assertRaises(v.InputCancelled):
            v.prompt_until_valid("x", v.validate_amount, input_fn=eof, print_fn=lambda *_: None)
        self.assertEqual(v.prompt_until_valid("x", v.validate_cause, default="Health",
                                              input_fn=lambda _: ""), "Health")
        self.assertIsNone(v.prompt_until_valid("x", v.validate_cause, optional=True, input_fn=lambda _: ""))


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.path = Path(self.tmp) / "d.json"

    def backups(self):
        return [p for p in Path(self.tmp).iterdir() if "corrupt" in p.name or "partial" in p.name]

    def test_missing_file_creates_template(self):
        s = Storage(self.path)
        self.assertEqual(s.load(), [])
        self.assertTrue(self.path.exists())
        self.assertEqual(json.loads(self.path.read_text())["donations"], [])

    def test_empty_and_corrupt_files_recover(self):
        for content in ["", "   ", "{not json", "[1,2", '{"donations": "oops"}', "42"]:
            self.path.write_text(content, encoding="utf-8")
            s = Storage(self.path)
            self.assertEqual(s.load(), [], msg=content)
            self.assertTrue(s.notes, msg=content)
            self.assertEqual(json.loads(self.path.read_text())["donations"], [])
        self.assertTrue(self.backups())

    def test_binary_file_recovers(self):
        self.path.write_bytes(b"\xff\xfe\x00bad")
        self.assertEqual(Storage(self.path).load(), [])

    def test_bad_records_are_skipped_and_good_kept(self):
        good = dict(id=1, date="2026-01-01", donor_name="Ann Lee", cause="Health", amount=5)
        bad = dict(id=2, date="nope", donor_name="Bob", cause="Health", amount=5)
        dup = dict(good, donor_name="Cy Dee")
        self.path.write_text(json.dumps({"donations": [good, bad, dup]}))
        s = Storage(self.path)
        loaded = s.load()
        self.assertEqual([d.donor_name for d in loaded], ["Ann Lee", "Cy Dee"])
        self.assertEqual(len({d.id for d in loaded}), 2)
        self.assertTrue(self.backups())

    def test_round_trip(self):
        L = new_ledger(self.tmp)
        L.add("2026-01-01", "Ann Lee", "Health", "10")
        self.assertEqual(len(Ledger(Storage(self.path)).donations), 1)


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.L = new_ledger(self.tmp)
        importer.import_csv(cfg.SAMPLE_CSV, self.L)

    def test_sample_loads_40(self):
        self.assertEqual(len(self.L.donations), 40)

    def test_add_edit_delete(self):
        d = self.L.add("2026-02-02", "Test Donor", "Other", "12.5", "Cash", "hi")
        self.assertEqual(d.id, 41)
        self.L.edit(41, amount="20")
        self.assertEqual(self.L.get(41).amount, 20.0)
        with self.assertRaises(v.ValidationError):
            self.L.edit(41, amount="-1")
        self.assertEqual(self.L.get(41).amount, 20.0)  # failed edit changes nothing
        self.L.delete(41)
        with self.assertRaises(NotFound):
            self.L.get(41)

    def test_invalid_add_not_saved(self):
        with self.assertRaises(v.ValidationError):
            self.L.add("2026-02-02", "", "Other", "5")
        self.assertEqual(len(self.L.donations), 40)

    def test_search(self):
        self.assertEqual(len(self.L.search("aarav")), 8)
        self.assertEqual(len(self.L.search(causes="Health")), 8)
        self.assertEqual(len(self.L.search(causes=["Health", "Other"])), 11)
        self.assertEqual(len(self.L.search(min_amount=10000)), 2)
        self.assertEqual(len(self.L.search(date_from="2026-02-01", date_to="2026-02-28")), 5)
        self.assertEqual(len(self.L.search("aarav", causes="Education", min_amount=250, max_amount=250)), 8)
        self.assertEqual(self.L.search("nonexistentword"), [])
        with self.assertRaises(v.ValidationError):
            self.L.search(date_from="2026-05-01", date_to="2026-01-01")
        with self.assertRaises(v.ValidationError):
            self.L.search(min_amount="abc")

    def test_totals_by_cause(self):
        totals = self.L.totals_by_cause()
        self.assertAlmostEqual(sum(totals.values()), 51761.74, places=2)
        self.assertEqual(next(iter(totals)), "Disaster Relief")


class ReportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.L = new_ledger(self.tmp)
        importer.import_csv(cfg.SAMPLE_CSV, self.L)
        self.s = reports.build_summary(self.L.donations, TODAY)

    def test_summary_numbers(self):
        s = self.s
        self.assertEqual(s["count"], 40)
        self.assertEqual(s["total"], 51761.74)
        self.assertEqual(s["median"], 250.0)
        self.assertEqual(s["largest"].amount, 25000.0)
        self.assertAlmostEqual(sum(r["share"] for r in s["by_cause"]), 100, delta=0.5)
        self.assertEqual(len(s["monthly"]), 11)
        self.assertEqual(s["mom_change_pct"], -51.4)

    def test_empty_summary(self):
        s = reports.build_summary([], TODAY)
        self.assertEqual(s["count"], 0)
        self.assertIn("No donations", reports.to_text(s))
        self.assertIn("No donations", reports.to_markdown(s))

    def test_alerts(self):
        titles = [a.title for a in alerts.find_alerts(self.L.donations, TODAY)]
        self.assertIn("Possible duplicate", titles)
        self.assertIn("Giving dropped last month", titles)
        self.assertIn("Large gift #33", titles)
        self.assertIn("Large gift #25", titles)   # exactly at the limit counts
        self.assertEqual(alerts.find_alerts([], TODAY), [])
        quiet = [a.title for a in alerts.find_alerts(self.L.donations, date(2027, 6, 1))]
        self.assertIn("No recent donations", quiet)

    def test_exports(self):
        out = Path(self.tmp) / "out"
        found = alerts.find_alerts(self.L.donations, TODAY)
        written = reports.export_all(self.L.donations, self.s, found, out)
        names = {p.name for p in written}
        for expected in ["summary_report.md", "audit_log.txt", "summary_by_group.csv", "donations.csv",
                         "monthly_trend.png"]:
            self.assertIn(expected, names)
        self.assertIn("| Cause |", (out / "summary_report.md").read_text(encoding="utf-8"))
        self.assertIn("AUDIT LOG", (out / "audit_log.txt").read_text(encoding="utf-8"))

    def test_csv_formula_injection_guard(self):
        self.L.add("2026-02-02", "Safe Name", "Other", "5", "Cash", "=HYPERLINK(1)")
        csv_text = reports.donations_csv(self.L.donations)
        self.assertIn("'=HYPERLINK(1)", csv_text)


class ImporterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.L = new_ledger(self.tmp)

    def test_messy_file(self):
        log = Path(self.tmp) / "log.txt"
        r = importer.import_csv(cfg.BAD_IMPORT_SAMPLE, self.L, log)
        self.assertEqual((r.imported, r.skipped), (3, 7))
        self.assertEqual({i.field for i in r.errors}, {"donor_name", "date", "cause", "amount"})
        self.assertEqual(len(self.L.donations), 3)
        text = log.read_text(encoding="utf-8")
        self.assertIn("line    3", text)
        self.assertIn("Barter", text)

    def test_fatal_cases(self):
        self.assertIn("not found", importer.import_csv("/no/such.csv", self.L).fatal)
        self.assertIn("empty", importer.import_text("", self.L).fatal)
        self.assertIn("Missing required", importer.import_text("a,b\n1,2\n", self.L).fatal)
        binary = Path(self.tmp) / "b.csv"
        binary.write_bytes(b"\xff\xfe\x00\x01")
        self.assertIn("UTF-8", importer.import_csv(binary, self.L).fatal)
        self.assertEqual(len(self.L.donations), 0)

    def test_aliases_and_bom_and_extra_columns(self):
        text = "\ufeffDonor,Date,Category,Value\nAnn Lee,2026-01-01,health,5\nBob Ray,2026-01-02,health,6,EXTRA\n"
        r = importer.import_text(text, self.L)
        self.assertEqual(r.imported, 1)
        self.assertEqual(r.skipped, 1)
        self.assertIn("Too many columns", r.errors[0].message)


if __name__ == "__main__":
    unittest.main()
