"""Regenerate data/sample_donations.json, sample_donations.csv and bad_import_example.csv."""
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from ledger import config as cfg  # noqa: E402

# date, donor, cause, amount, method, notes
ROWS = [
    ("2026-01-05", "Aarav Sharma", "Education", 250.00, "UPI", "New year scholarship fund"),
    ("2026-01-12", "Maria Gonzalez", "Health", 120.00, "Card", ""),
    ("2026-01-18", "Greenleaf Foundation", "Environment", 1500.00, "Bank Transfer", "Tree planting drive"),
    ("2026-01-31", "Liam O'Brien", "Hunger & Food", 75.50, "Cash", "Month-end boundary"),
    ("2026-02-01", "Priya Nair", "Animal Welfare", 60.00, "UPI", "Month-start boundary"),
    ("2026-02-09", "Anonymous", "Other", 1.00, "Cash", "Minimum-size gift"),
    ("2026-02-14", "José Martínez", "Education", 300.00, "Card", "Valentine's giving"),
    ("2026-02-20", "Sunrise Rotary Club", "Hunger & Food", 2200.00, "Cheque", "Community kitchen"),
    ("2026-02-27", "Chen Wei", "Health", 180.00, "Online", ""),
    ("2026-03-03", "Fatima Khan", "Education", 500.00, "Bank Transfer", "Books for rural library"),
    ("2026-03-10", "Sofia Rossi", "Animal Welfare", 95.25, "Card", ""),
    ("2026-03-15", "Anonymous", "Disaster Relief", 400.00, "Cash", "Flood relief"),
    ("2026-03-22", "Ravi Patel", "Environment", 150.00, "UPI", ""),
    ("2026-03-29", "Hannah Müller", "Health", 640.00, "Online", "Clinic equipment"),
    ("2026-04-02", "Aarav Sharma", "Education", 250.00, "UPI", "Monthly pledge"),
    ("2026-04-11", "Blue Horizon Trust", "Disaster Relief", 5000.00, "Bank Transfer", "Cyclone response"),
    ("2026-04-19", "Emily Johnson", "Hunger & Food", 85.00, "Card", ""),
    ("2026-04-25", "Omar Haddad", "Health", 210.00, "Cash", ""),
    ("2026-05-04", "Aarav Sharma", "Education", 250.00, "UPI", "Monthly pledge"),
    ("2026-05-08", "Maria Gonzalez", "Health", 120.00, "Card", ""),
    ("2026-05-08", "Maria Gonzalez", "Health", 120.00, "Card", "Possible duplicate entry"),
    ("2026-05-17", "Kenji Tanaka", "Environment", 320.00, "Online", "River cleanup"),
    ("2026-05-30", "Lakshmi Iyer", "Animal Welfare", 45.00, "UPI", ""),
    ("2026-06-06", "Aarav Sharma", "Education", 250.00, "UPI", "Monthly pledge"),
    ("2026-06-14", "Tech4Good Inc.", "Education", 10000.00, "Bank Transfer", "Exactly at the large-gift limit"),
    ("2026-06-21", "Grace Okafor", "Hunger & Food", 130.00, "Cash", ""),
    ("2026-06-28", "Noah Williams", "Other", 55.00, "Card", ""),
    ("2026-07-03", "Aarav Sharma", "Education", 250.00, "UPI", "Monthly pledge"),
    ("2026-07-12", "Ananya Rao", "Health", 780.00, "Online", "Surgery fund"),
    ("2026-07-19", "Liam O'Brien", "Environment", 99.99, "Card", ""),
    ("2026-07-26", "Olivia Brown", "Animal Welfare", 275.00, "Cheque", "Shelter roof repairs"),
    ("2026-08-02", "Aarav Sharma", "Education", 250.00, "UPI", "Monthly pledge"),
    ("2026-08-15", "Harbor Light Society", "Disaster Relief", 25000.00, "Bank Transfer", "Record gift (outlier test)"),
    ("2026-08-23", "Daniel Kim", "Hunger & Food", 160.00, "UPI", ""),
    ("2026-09-05", "Aarav Sharma", "Education", 250.00, "UPI", "Monthly pledge"),
    ("2026-09-13", "Meera Krishnan", "Health", 430.00, "Card", ""),
    ("2026-09-27", "Anonymous", "Other", 20.00, "Cash", ""),
    ("2026-10-04", "Aarav Sharma", "Education", 250.00, "UPI", "Monthly pledge"),
    ("2026-10-18", "Isabella Costa", "Environment", 90.00, "Online", "Quiet month"),
    ("2026-11-08", "Sunrise Rotary Club", "Hunger & Food", 600.00, "Cheque", "Winter meal packs"),
]

BAD = [
    ["date", "donor_name", "cause", "amount", "payment_method", "notes"],
    ["2026-10-02", "Rhea Kapoor", "Education", "150", "UPI", "Valid row"],
    ["2026-10-03", "", "Health", "80", "Cash", "Missing donor name"],
    ["03/10/2026", "Tom Baker", "Health", "80", "Cash", "Wrong date format"],
    ["2026-10-05", "Zara Ali", "Charity", "50", "Card", "Unknown cause"],
    ["2026-10-06", "Pedro Alves", "Environment", "twenty", "Cash", "Amount is not a number"],
    ["2026-10-07", "Ines Duarte", "Environment", "-40", "Cash", "Negative amount"],
    ["2099-01-01", "Future Fran", "Other", "10", "Cash", "Date in the future"],
    ["2026-10-09", "Wei Zhang", "Animal Welfare", "35.50", "Barter", "Unknown method becomes Other"],
    ["", "", "", "", "", ""],
    ["2026-10-10", "Uma Devi", "Hunger & Food", "1,250.00", "Cheque", "Comma thousands separator is fine"],
    ["2026-10-11", "=cmd|' /C calc'!A0", "Other", "5", "Cash", "Formula-style name is rejected"],
]


def main() -> None:
    cfg.DATA_DIR.mkdir(exist_ok=True)
    records = [dict(id=i, date=d, donor_name=n, cause=c, amount=a, payment_method=m, notes=t)
               for i, (d, n, c, a, m, t) in enumerate(ROWS, start=1)]
    assert len(records) == 40
    cfg.SAMPLE_JSON.write_text(json.dumps(
        {"schema_version": 1, "donations": records}, indent=2, ensure_ascii=False), encoding="utf-8")
    with open(cfg.SAMPLE_CSV, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["date", "donor_name", "cause", "amount", "payment_method", "notes"])
        for r in ROWS:
            w.writerow([r[0], r[1], r[2], f"{r[3]:.2f}", r[4], r[5]])
    with open(cfg.BAD_IMPORT_SAMPLE, "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows(BAD)
    print(f"Wrote {len(records)} sample records and {len(BAD) - 1} messy import rows.")


if __name__ == "__main__":
    main()
