"""Terminal entry point:  python main.py"""
import sys

from ledger.cli import main

if __name__ == "__main__":
    sys.exit(main())
